from django.test import Client, TestCase

from accounts.auth_utils import sync_profile_user
from applications.models import (
    AcceleratorApplication,
    FellowApplication,
    InternshipApplication,
    InvestorApplication,
    MentorApplication,
    StartupApplication,
    VendorApplication,
)
from superadmin.models import CenterAdmin, IncubationCenter


class CenterAdminViewTests(TestCase):
    def setUp(self):
        self.client = Client()
        self.center = IncubationCenter.objects.create(
            name="VNIT Incubation Hub",
            city="Nagpur",
            contact_email="center@example.com",
            phone_number="9876543210",
            website_url="https://example.com",
            capacity=120,
            status="active",
        )
        self.center_admin = CenterAdmin.objects.create(
            full_name="Center Admin",
            email="admin@example.com",
            phone_number="9123456789",
            center=self.center,
            status="active",
        )
        sync_profile_user(
            self.center_admin,
            "centeradmin",
            self.center_admin.email,
            password="Admin@123",
            email=self.center_admin.email,
            full_name=self.center_admin.full_name,
            is_active=True,
        )
        self.startup = StartupApplication.objects.create(
            center=self.center,
            startup_comp_name="Nova Labs",
            comp_choices="startup",
            founder_name="Asha Patil",
            email="asha@example.com",
            category="technology",
            about_confirmation="yes",
            start_up_details="Startup detail",
            status="pending",
        )
        self.accelerator = AcceleratorApplication.objects.create(
            center=self.center,
            startup_name="Scale Nova",
            founder_name="Rohit Sharma",
            email="rohit@example.com",
            category="technology",
            contact_number="9876543210",
            one_line_description="Growth stage",
            startup_details="Accelerator detail",
            source="Referral",
            status="pending",
        )
        self.fellow = FellowApplication.objects.create(
            center=self.center,
            full_name="Neha Kulkarni",
            email="neha@example.com",
            phone_number="9876543210",
            highest_qualification="MBA",
            specialization="Innovation",
            statement_of_purpose="Interested in incubation fellowship",
            status="pending",
        )
        self.internship = InternshipApplication.objects.create(
            center=self.center,
            full_name="Amit Joshi",
            email="amit@example.com",
            phone_number="9876543211",
            college_name="VNIT",
            course_name="BTech",
            preferred_domain="Operations",
            duration_weeks=8,
            internship_interest="Incubation exposure",
            status="pending",
        )
        self.mentor = MentorApplication.objects.create(
            center=self.center,
            full_name="Priya Deshmukh",
            email="priya@example.com",
            phone_number="9876543212",
            expertise_area="Finance",
            current_organization="Fin Growth",
            years_of_experience=12,
            profile_summary="Mentor profile",
            status="pending",
        )
        self.investor = InvestorApplication.objects.create(
            center=self.center,
            organization_name="Alpha Capital",
            contact_person="Ritesh Mehta",
            email="ritesh@example.com",
            phone_number="9876543213",
            investment_focus="Seed",
            ticket_size="25L-50L",
            investment_note="Looking for early stage startups",
            status="pending",
        )
        self.vendor = VendorApplication.objects.create(
            center=self.center,
            company_name="Service Desk Pro",
            contact_person="Kiran Patil",
            email="kiran@example.com",
            phone_number="9876543214",
            service_category="IT Services",
            service_details="Support services",
            status="pending",
        )

    def login_center_admin(self):
        return self.client.post(
            "/centeradmin/login/",
            {
                "role": "admin",
                "email": "admin@example.com",
                "password": "Admin@123",
            },
        )

    def test_login_works(self):
        response = self.login_center_admin()
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.url, "/centeradmin/dashboard/")

    def test_dashboard_requires_login(self):
        response = self.client.get("/centeradmin/dashboard/")
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response.url, "/centeradmin/login/")

    def test_startup_list_works_after_login(self):
        self.login_center_admin()
        response = self.client.get("/centeradmin/startup-list/")
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Nova Labs")

    def test_accelerator_list_works_after_login(self):
        self.login_center_admin()
        response = self.client.get("/centeradmin/accelerator-list/")
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Scale Nova")

    def test_other_module_lists_work_after_login(self):
        self.login_center_admin()

        response = self.client.get("/centeradmin/fellow-list/")
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Neha Kulkarni")

        response = self.client.get("/centeradmin/internship-list/")
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Amit Joshi")

        response = self.client.get("/centeradmin/mentor-list/")
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Priya Deshmukh")

        response = self.client.get("/centeradmin/investor-list/")
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Alpha Capital")

        response = self.client.get("/centeradmin/vendor-list/")
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Service Desk Pro")

    def test_other_module_view_and_edit_pages_work_after_login(self):
        self.login_center_admin()

        response = self.client.get(f"/centeradmin/fellow-view/{self.fellow.pk}/")
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Neha Kulkarni")

        response = self.client.post(
            f"/centeradmin/fellow-edit/{self.fellow.pk}/",
            {"status": "approved"},
        )
        self.assertEqual(response.status_code, 302)
        self.fellow.refresh_from_db()
        self.assertEqual(self.fellow.status, "approved")

        response = self.client.get(f"/centeradmin/mentor-view/{self.mentor.pk}/")
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Priya Deshmukh")

        response = self.client.get(f"/centeradmin/vendor-edit/{self.vendor.pk}/")
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Update Vendor Application Status")
