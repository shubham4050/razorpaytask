from functools import wraps

from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.db.models import Q
from django.shortcuts import get_object_or_404, redirect, render

from accounts.auth_utils import sync_profile_user
from applications.models import (
    AcceleratorApplication,
    FellowApplication,
    InternshipApplication,
    InvestorApplication,
    MentorApplication,
    StartupApplication,
    VendorApplication,
)

from accelerator.models import (
    AcceleratorProgram,
    AcceleratorMilestone,
    AcceleratorDocument,
    AcceleratorNotice,
)

from superadmin.models import CenterAdmin


def sync_application_user_status(application):
    if application.user_id:
        application.user.is_active = application.status == "approved"
        application.user.save(update_fields=["is_active"])


def centeradmin_required(view_func):
    @wraps(view_func)
    def wrapper(request, *args, **kwargs):
        if not request.user.is_authenticated:
            return redirect("centeradmin:login")

        center_admin = (
            CenterAdmin.objects.select_related("center")
            .filter(user=request.user)
            .first()
        )

        if not center_admin:
            return redirect("centeradmin:login")

        if center_admin.status != "active" or center_admin.center.status != "active":
            logout(request)
            messages.error(request, "Your admin access is inactive.")
            return redirect("centeradmin:login")

        request.center_admin = center_admin
        return view_func(request, *args, **kwargs)

    return wrapper


def login_view(request):
    if request.user.is_authenticated and hasattr(request.user, "center_admin_profile"):
        return redirect("centeradmin:dashboard")

    if request.method == "POST":
        role = request.POST.get("role", "admin").strip()
        email = request.POST.get("email", "").strip()
        password = request.POST.get("password", "").strip()
        center_admin = CenterAdmin.objects.select_related("center", "user").filter(email=email).first()

        if role != "admin":
            messages.error(request, "Please select the correct role.")
            return render(request, "centeradmin/login.html", {"email_value": email})
        if not center_admin:
            messages.error(request, "Admin account not found.")
            return render(request, "centeradmin/login.html", {"email_value": email})
        if center_admin.status != "active" or center_admin.center.status != "active":
            messages.error(request, "This admin account is inactive.")
            return render(request, "centeradmin/login.html", {"email_value": email})

        if not center_admin.user:
            messages.error(request, "Login credentials are not set for this admin.")
            return render(request, "centeradmin/login.html", {"email_value": email})

        user = authenticate(request, username=center_admin.user.username, password=password)
        if not user:
            messages.error(request, "Invalid credentials.")
            return render(request, "centeradmin/login.html", {"email_value": email})

        login(request, user)
        return redirect("centeradmin:dashboard")

    return render(request, "centeradmin/login.html")


@centeradmin_required
def dashboard_view(request):
    center_id = request.center_admin.center_id
    startup_queryset = StartupApplication.objects.filter(center_id=center_id)
    accelerator_queryset = AcceleratorApplication.objects.filter(center_id=center_id)
    fellow_queryset = FellowApplication.objects.filter(center_id=center_id)
    internship_queryset = InternshipApplication.objects.filter(center_id=center_id)
    mentor_queryset = MentorApplication.objects.filter(center_id=center_id)
    investor_queryset = InvestorApplication.objects.filter(center_id=center_id)
    vendor_queryset = VendorApplication.objects.filter(center_id=center_id)

    return render(
        request,
        "centeradmin/dashboard.html",
        {
            "center_admin": request.center_admin,
            "center": request.center_admin.center,
            "startup_total": startup_queryset.count(),
            "accelerator_total": accelerator_queryset.count(),
            "fellow_total": fellow_queryset.count(),
            "internship_total": internship_queryset.count(),
            "mentor_total": mentor_queryset.count(),
            "investor_total": investor_queryset.count(),
            "vendor_total": vendor_queryset.count(),
            "startup_pending": startup_queryset.filter(status="pending").count(),
            "accelerator_pending": accelerator_queryset.filter(status="pending").count(),
            "fellow_pending": fellow_queryset.filter(status="pending").count(),
            "internship_pending": internship_queryset.filter(status="pending").count(),
            "mentor_pending": mentor_queryset.filter(status="pending").count(),
            "investor_pending": investor_queryset.filter(status="pending").count(),
            "vendor_pending": vendor_queryset.filter(status="pending").count(),
            "recent_startups": startup_queryset[:5],
            "recent_accelerators": accelerator_queryset[:5],
        },
    )


@centeradmin_required
def startup_list(request):
    q = request.GET.get("q", "").strip()
    startups = StartupApplication.objects.filter(center_id=request.center_admin.center_id).order_by("-created_at")

    if q:
        startups = startups.filter(startup_comp_name__icontains=q)

    return render(
        request,
        "centeradmin/startup_list.html",
        {
            "startups": startups,
            "q": q,
            "center_admin": request.center_admin,
            "center": request.center_admin.center,
        },
    )


@centeradmin_required
def startup_view(request, pk):
    startup = get_object_or_404(StartupApplication, pk=pk, center_id=request.center_admin.center_id)
    return render(
        request,
        "centeradmin/startup_view.html",
        {
            "startup": startup,
            "center_admin": request.center_admin,
            "center": request.center_admin.center,
        },
    )


@centeradmin_required
def startup_edit(request, pk):
    startup = get_object_or_404(StartupApplication, pk=pk, center_id=request.center_admin.center_id)

    if request.method == "POST":
        startup.status = request.POST.get("status", startup.status)
        startup.save()
        sync_application_user_status(startup)
        messages.success(request, "Startup status updated successfully.")
        return redirect("centeradmin:startup_list")

    return render(
        request,
        "centeradmin/startup_edit.html",
        {
            "startup": startup,
            "status_choices": StartupApplication._meta.get_field("status").choices,
            "center_admin": request.center_admin,
            "center": request.center_admin.center,
        },
    )


@centeradmin_required
def startup_create_credentials(request, pk):
    startup = get_object_or_404(StartupApplication, pk=pk, center_id=request.center_admin.center_id)

    if request.method == "POST":
        username = request.POST.get("username", "").strip()
        password = request.POST.get("password", "").strip()

        if not username or not password:
            messages.error(request, "Username and password are required.")
        elif StartupApplication.objects.filter(login_username=username).exclude(pk=pk).exists():
            messages.error(request, "This username is already taken.")
        else:
            startup.login_username = username
            sync_profile_user(
                startup,
                "startup",
                username,
                password=password,
                email=startup.email,
                full_name=startup.startup_comp_name,
                is_active=startup.status == "approved",
            )
            startup.save()
            messages.success(request, f"Credentials created for {startup.startup_comp_name}. Username: {username}")
            return redirect("centeradmin:startup_view", pk=pk)

    return render(request, "centeradmin/startup_credentials.html", {
        "startup": startup,
        "center_admin": request.center_admin,
        "center": request.center_admin.center,
    })

@centeradmin_required
def accelerator_list(request):
    q = request.GET.get("q", "").strip()
    applications = AcceleratorApplication.objects.filter(center_id=request.center_admin.center_id).order_by("-created_at")

    if q:
        applications = applications.filter(startup_name__icontains=q)

    return render(
        request,
        "centeradmin/accelerator_list.html",
        {
            "applications": applications,
            "q": q,
            "center_admin": request.center_admin,
            "center": request.center_admin.center,
        },
    )


@centeradmin_required
def accelerator_view(request, pk):
    application = get_object_or_404(AcceleratorApplication, pk=pk, center_id=request.center_admin.center_id)
    program     = AcceleratorProgram.objects.filter(accelerator=application).first()
    milestones  = AcceleratorMilestone.objects.filter(accelerator=application)
    documents   = AcceleratorDocument.objects.filter(accelerator=application)
    notices     = AcceleratorNotice.objects.filter(accelerator=application)

    return render(request, "centeradmin/accelerator_view.html", {
        "application":  application,
        "program":      program,
        "milestones":   milestones,
        "documents":    documents,
        "notices":      notices,
        "center_admin": request.center_admin,
        "center":       request.center_admin.center,
    })


@centeradmin_required
def accelerator_edit(request, pk):
    application = get_object_or_404(AcceleratorApplication, pk=pk, center_id=request.center_admin.center_id)

    if request.method == "POST":
        application.status = request.POST.get("status", application.status)
        application.save()
        sync_application_user_status(application)
        messages.success(request, "Accelerator status updated successfully.")
        return redirect("centeradmin:accelerator_list")

    return render(
        request,
        "centeradmin/accelerator_edit.html",
        {
            "application": application,
            "status_choices": AcceleratorApplication._meta.get_field("status").choices,
            "center_admin": request.center_admin,
            "center": request.center_admin.center,
        },
    )

# AcceleratorApplication
@centeradmin_required
def accelerator_create_credentials(request, pk):
    accelerator = get_object_or_404(AcceleratorApplication, pk=pk, center_id=request.center_admin.center_id)

    if request.method == "POST":
        username = request.POST.get("username", "").strip()
        password = request.POST.get("password", "").strip()

        if not username or not password:
            messages.error(request, "Username and password are required.")
        elif AcceleratorApplication.objects.filter(login_username=username).exclude(pk=pk).exists():
            messages.error(request, "This username is already taken.")
        else:
            accelerator.login_username = username
            sync_profile_user(
                accelerator,
                "accelerator",
                username,
                password=password,
                email=accelerator.email,
                full_name=accelerator.startup_name,
                is_active=accelerator.status == "approved",
            )
            accelerator.save()
            messages.success(request, f"Credentials created for {accelerator.startup_name}. Username: {username}")
            return redirect("centeradmin:accelerator_view", pk=pk)

    return render(request, "centeradmin/accelerator_credentials.html", {
        "accelerator": accelerator,
        "center_admin": request.center_admin,
        "center": request.center_admin.center,
    })


@centeradmin_required
def fellow_list(request):
    q = request.GET.get("q", "").strip()
    fellows = FellowApplication.objects.filter(center_id=request.center_admin.center_id).order_by("-created_at")

    if q:
        fellows = fellows.filter(
            Q(full_name__icontains=q)
            | Q(email__icontains=q)
            | Q(specialization__icontains=q)
            | Q(highest_qualification__icontains=q)
        )

    return render(
        request,
        "centeradmin/fellow_list.html",
        {
            "fellows": fellows,
            "q": q,
            "center_admin": request.center_admin,
            "center": request.center_admin.center,
        },
    )


@centeradmin_required
def fellow_view(request, pk):
    fellow = get_object_or_404(FellowApplication, pk=pk, center_id=request.center_admin.center_id)
    return render(
        request,
        "centeradmin/fellow_view.html",
        {
            "fellow": fellow,
            "center_admin": request.center_admin,
            "center": request.center_admin.center,
        },
    )


@centeradmin_required
def fellow_edit(request, pk):
    fellow = get_object_or_404(FellowApplication, pk=pk, center_id=request.center_admin.center_id)

    if request.method == "POST":
        fellow.status = request.POST.get("status", fellow.status)
        fellow.save()
        sync_application_user_status(fellow)
        messages.success(request, "Fellow application status updated successfully.")
        return redirect("centeradmin:fellow_list")

    return render(
        request,
        "centeradmin/fellow_edit.html",
        {
            "fellow": fellow,
            "status_choices": FellowApplication._meta.get_field("status").choices,
            "center_admin": request.center_admin,
            "center": request.center_admin.center,
        },
    )

# FellowApplication
@centeradmin_required
def fellow_create_credentials(request, pk):
    fellow = get_object_or_404(FellowApplication, pk=pk, center_id=request.center_admin.center_id)

    if request.method == "POST":
        username = request.POST.get("username", "").strip()
        password = request.POST.get("password", "").strip()

        if not username or not password:
            messages.error(request, "Username and password are required.")
        elif FellowApplication.objects.filter(login_username=username).exclude(pk=pk).exists():
            messages.error(request, "This username is already taken.")
        else:
            fellow.login_username = username
            sync_profile_user(
                fellow,
                "fellow",
                username,
                password=password,
                email=fellow.email,
                full_name=fellow.full_name,
                is_active=fellow.status == "approved",
            )
            fellow.save()
            messages.success(request, f"Credentials created for {fellow.full_name}. Username: {username}")
            return redirect("centeradmin:fellow_view", pk=pk)

    return render(request, "centeradmin/fellow_credentials.html", {
        "fellow": fellow,
        "center_admin": request.center_admin,
        "center": request.center_admin.center,
    })

@centeradmin_required
def internship_list(request):
    q = request.GET.get("q", "").strip()
    internships = InternshipApplication.objects.filter(center_id=request.center_admin.center_id).order_by("-created_at")

    if q:
        internships = internships.filter(
            Q(full_name__icontains=q)
            | Q(email__icontains=q)
            | Q(college_name__icontains=q)
            | Q(course_name__icontains=q)
        )

    return render(
        request,
        "centeradmin/internship_list.html",
        {
            "internships": internships,
            "q": q,
            "center_admin": request.center_admin,
            "center": request.center_admin.center,
        },
    )


@centeradmin_required
def internship_view(request, pk):
    internship = get_object_or_404(InternshipApplication, pk=pk, center_id=request.center_admin.center_id)
    return render(
        request,
        "centeradmin/internship_view.html",
        {
            "internship": internship,
            "center_admin": request.center_admin,
            "center": request.center_admin.center,
        },
    )


@centeradmin_required
def internship_edit(request, pk):
    internship = get_object_or_404(InternshipApplication, pk=pk, center_id=request.center_admin.center_id)

    if request.method == "POST":
        internship.status = request.POST.get("status", internship.status)
        internship.save()
        sync_application_user_status(internship)
        messages.success(request, "Internship application status updated successfully.")
        return redirect("centeradmin:internship_list")

    return render(
        request,
        "centeradmin/internship_edit.html",
        {
            "internship": internship,
            "status_choices": InternshipApplication._meta.get_field("status").choices,
            "center_admin": request.center_admin,
            "center": request.center_admin.center,
        },
    )

# InternshipApplication
@centeradmin_required
def internship_create_credentials(request, pk):
    internship = get_object_or_404(InternshipApplication, pk=pk, center_id=request.center_admin.center_id)

    if request.method == "POST":
        username = request.POST.get("username", "").strip()
        password = request.POST.get("password", "").strip()

        if not username or not password:
            messages.error(request, "Username and password are required.")
        elif InternshipApplication.objects.filter(login_username=username).exclude(pk=pk).exists():
            messages.error(request, "This username is already taken.")
        else:
            internship.login_username = username
            sync_profile_user(
                internship,
                "internship",
                username,
                password=password,
                email=internship.email,
                full_name=internship.full_name,
                is_active=internship.status == "approved",
            )
            internship.save()
            messages.success(request, f"Credentials created for {internship.full_name}. Username: {username}")
            return redirect("centeradmin:internship_view", pk=pk)

    return render(request, "centeradmin/internship_credentials.html", {
        "internship": internship,
        "center_admin": request.center_admin,
        "center": request.center_admin.center,
    })


@centeradmin_required
def mentor_list(request):
    q = request.GET.get("q", "").strip()
    mentors = MentorApplication.objects.filter(center_id=request.center_admin.center_id).order_by("-created_at")

    if q:
        mentors = mentors.filter(
            Q(full_name__icontains=q)
            | Q(email__icontains=q)
            | Q(expertise_area__icontains=q)
            | Q(current_organization__icontains=q)
        )

    return render(
        request,
        "centeradmin/mentor_list.html",
        {
            "mentors": mentors,
            "q": q,
            "center_admin": request.center_admin,
            "center": request.center_admin.center,
        },
    )


@centeradmin_required
def mentor_view(request, pk):
    mentor = get_object_or_404(MentorApplication, pk=pk, center_id=request.center_admin.center_id)
    return render(
        request,
        "centeradmin/mentor_view.html",
        {
            "mentor": mentor,
            "center_admin": request.center_admin,
            "center": request.center_admin.center,
        },
    )


@centeradmin_required
def mentor_edit(request, pk):
    mentor = get_object_or_404(MentorApplication, pk=pk, center_id=request.center_admin.center_id)

    if request.method == "POST":
        mentor.status = request.POST.get("status", mentor.status)
        mentor.save()
        sync_application_user_status(mentor)
        messages.success(request, "Mentor application status updated successfully.")
        return redirect("centeradmin:mentor_list")

    return render(
        request,
        "centeradmin/mentor_edit.html",
        {
            "mentor": mentor,
            "status_choices": MentorApplication._meta.get_field("status").choices,
            "center_admin": request.center_admin,
            "center": request.center_admin.center,
        },
    )

# MentorApplication
@centeradmin_required
def mentor_create_credentials(request, pk):
    mentor = get_object_or_404(MentorApplication, pk=pk, center_id=request.center_admin.center_id)

    if request.method == "POST":
        username = request.POST.get("username", "").strip()
        password = request.POST.get("password", "").strip()

        if not username or not password:
            messages.error(request, "Username and password are required.")
        elif MentorApplication.objects.filter(login_username=username).exclude(pk=pk).exists():
            messages.error(request, "This username is already taken.")
        else:
            mentor.login_username = username
            sync_profile_user(
                mentor,
                "mentor",
                username,
                password=password,
                email=mentor.email,
                full_name=mentor.full_name,
                is_active=mentor.status == "approved",
            )
            mentor.save()
            messages.success(request, f"Credentials created for {mentor.full_name}. Username: {username}")
            return redirect("centeradmin:mentor_view", pk=pk)

    return render(request, "centeradmin/mentor_credentials.html", {
        "mentor": mentor,
        "center_admin": request.center_admin,
        "center": request.center_admin.center,
    })

@centeradmin_required
def investor_list(request):
    q = request.GET.get("q", "").strip()
    investors = InvestorApplication.objects.filter(center_id=request.center_admin.center_id).order_by("-created_at")

    if q:
        investors = investors.filter(
            Q(organization_name__icontains=q)
            | Q(contact_person__icontains=q)
            | Q(email__icontains=q)
            | Q(investment_focus__icontains=q)
        )

    return render(
        request,
        "centeradmin/investor_list.html",
        {
            "investors": investors,
            "q": q,
            "center_admin": request.center_admin,
            "center": request.center_admin.center,
        },
    )


@centeradmin_required
def investor_view(request, pk):
    investor = get_object_or_404(InvestorApplication, pk=pk, center_id=request.center_admin.center_id)
    return render(
        request,
        "centeradmin/investor_view.html",
        {
            "investor": investor,
            "center_admin": request.center_admin,
            "center": request.center_admin.center,
        },
    )


@centeradmin_required
def investor_edit(request, pk):
    investor = get_object_or_404(InvestorApplication, pk=pk, center_id=request.center_admin.center_id)

    if request.method == "POST":
        investor.status = request.POST.get("status", investor.status)
        investor.save()
        sync_application_user_status(investor)
        messages.success(request, "Investor application status updated successfully.")
        return redirect("centeradmin:investor_list")

    return render(
        request,
        "centeradmin/investor_edit.html",
        {
            "investor": investor,
            "status_choices": InvestorApplication._meta.get_field("status").choices,
            "center_admin": request.center_admin,
            "center": request.center_admin.center,
        },
    )

# InvestorApplication
@centeradmin_required
def investor_create_credentials(request, pk):
    investor = get_object_or_404(InvestorApplication, pk=pk, center_id=request.center_admin.center_id)

    if request.method == "POST":
        username = request.POST.get("username", "").strip()
        password = request.POST.get("password", "").strip()

        if not username or not password:
            messages.error(request, "Username and password are required.")
        elif InvestorApplication.objects.filter(login_username=username).exclude(pk=pk).exists():
            messages.error(request, "This username is already taken.")
        else:
            investor.login_username = username
            sync_profile_user(
                investor,
                "investor",
                username,
                password=password,
                email=investor.email,
                full_name=investor.organization_name,
                is_active=investor.status == "approved",
            )
            investor.save()
            messages.success(request, f"Credentials created for {investor.organization_name}. Username: {username}")
            return redirect("centeradmin:investor_view", pk=pk)

    return render(request, "centeradmin/investor_credentials.html", {
        "investor": investor,
        "center_admin": request.center_admin,
        "center": request.center_admin.center,
    })

@centeradmin_required
def vendor_list(request):
    q = request.GET.get("q", "").strip()
    vendors = VendorApplication.objects.filter(center_id=request.center_admin.center_id).order_by("-created_at")

    if q:
        vendors = vendors.filter(
            Q(company_name__icontains=q)
            | Q(contact_person__icontains=q)
            | Q(email__icontains=q)
            | Q(service_category__icontains=q)
        )

    return render(
        request,
        "centeradmin/vendor_list.html",
        {
            "vendors": vendors,
            "q": q,
            "center_admin": request.center_admin,
            "center": request.center_admin.center,
        },
    )


@centeradmin_required
def vendor_view(request, pk):
    vendor = get_object_or_404(VendorApplication, pk=pk, center_id=request.center_admin.center_id)
    return render(
        request,
        "centeradmin/vendor_view.html",
        {
            "vendor": vendor,
            "center_admin": request.center_admin,
            "center": request.center_admin.center,
        },
    )


@centeradmin_required
def vendor_edit(request, pk):
    vendor = get_object_or_404(VendorApplication, pk=pk, center_id=request.center_admin.center_id)

    if request.method == "POST":
        vendor.status = request.POST.get("status", vendor.status)
        vendor.save()
        sync_application_user_status(vendor)
        messages.success(request, "Vendor application status updated successfully.")
        return redirect("centeradmin:vendor_list")

    return render(
        request,
        "centeradmin/vendor_edit.html",
        {
            "vendor": vendor,
            "status_choices": VendorApplication._meta.get_field("status").choices,
            "center_admin": request.center_admin,
            "center": request.center_admin.center,
        },
    )

# VendorApplication
@centeradmin_required
def vendor_create_credentials(request, pk):
    vendor = get_object_or_404(VendorApplication, pk=pk, center_id=request.center_admin.center_id)

    if request.method == "POST":
        username = request.POST.get("username", "").strip()
        password = request.POST.get("password", "").strip()

        if not username or not password:
            messages.error(request, "Username and password are required.")
        elif VendorApplication.objects.filter(login_username=username).exclude(pk=pk).exists():
            messages.error(request, "This username is already taken.")
        else:
            vendor.login_username = username
            sync_profile_user(
                vendor,
                "vendor",
                username,
                password=password,
                email=vendor.email,
                full_name=vendor.company_name,
                is_active=vendor.status == "approved",
            )
            vendor.save()
            messages.success(request, f"Credentials created for {vendor.company_name}. Username: {username}")
            return redirect("centeradmin:vendor_view", pk=pk)

    return render(request, "centeradmin/vendor_credentials.html", {
        "vendor": vendor,
        "center_admin": request.center_admin,
        "center": request.center_admin.center,
    })

# ══════════════════════════════════════════════════════════════════════════════
# ACCELERATOR PROGRAM MANAGEMENT
# ══════════════════════════════════════════════════════════════════════════════

@centeradmin_required
def accelerator_program_set(request, pk):
    """Create or update program details for an accelerator."""
    application = get_object_or_404(AcceleratorApplication, pk=pk, center_id=request.center_admin.center_id)
    program, created = AcceleratorProgram.objects.get_or_create(accelerator=application)

    if request.method == "POST":
        program.program_name = request.POST.get("program_name", "").strip()
        program.batch_name = request.POST.get("batch_name", "").strip()
        program.start_date = request.POST.get("start_date") or None
        program.end_date = request.POST.get("end_date") or None
        program.current_stage = request.POST.get("current_stage", "").strip()
        program.notes = request.POST.get("notes", "").strip()
        program.save()
        messages.success(request, "Program details saved successfully.")
        return redirect("centeradmin:accelerator_view", pk=pk)

    return render(request, "centeradmin/accelerator_program_set.html", {
        "application": application,
        "program": program,
        "center_admin": request.center_admin,
        "center": request.center_admin.center,
    })


# ══════════════════════════════════════════════════════════════════════════════
# ACCELERATOR MILESTONE MANAGEMENT
# ══════════════════════════════════════════════════════════════════════════════

@centeradmin_required
def accelerator_milestone_add(request, pk):
    """Add a new milestone for an accelerator."""
    application = get_object_or_404(AcceleratorApplication, pk=pk, center_id=request.center_admin.center_id)

    if request.method == "POST":
        title = request.POST.get("title", "").strip()
        description = request.POST.get("description", "").strip()
        due_date = request.POST.get("due_date") or None

        if not title:
            messages.error(request, "Milestone title is required.")
        else:
            AcceleratorMilestone.objects.create(
                accelerator=application,
                title=title,
                description=description,
                due_date=due_date,
                status="pending",
            )
            messages.success(request, f"Milestone '{title}' added successfully.")
            return redirect("centeradmin:accelerator_view", pk=pk)

    return render(request, "centeradmin/accelerator_milestone_add.html", {
        "application": application,
        "center_admin": request.center_admin,
        "center": request.center_admin.center,
    })


@centeradmin_required
def accelerator_milestone_review(request, pk, milestone_pk):
    """Review a submitted milestone — approve or reject with feedback."""
    application = get_object_or_404(AcceleratorApplication, pk=pk, center_id=request.center_admin.center_id)
    milestone = get_object_or_404(AcceleratorMilestone, pk=milestone_pk, accelerator=application)

    if request.method == "POST":
        status = request.POST.get("status", "").strip()
        admin_feedback = request.POST.get("admin_feedback", "").strip()

        if status not in ("approved", "rejected"):
            messages.error(request, "Please select a valid status.")
        else:
            milestone.status = status
            milestone.admin_feedback = admin_feedback
            milestone.save()
            messages.success(request, f"Milestone '{milestone.title}' marked as {status}.")
            return redirect("centeradmin:accelerator_view", pk=pk)

    return render(request, "centeradmin/accelerator_milestone_review.html", {
        "application": application,
        "milestone": milestone,
        "center_admin": request.center_admin,
        "center": request.center_admin.center,
    })


@centeradmin_required
def accelerator_milestone_delete(request, pk, milestone_pk):
    """Delete a milestone."""
    application = get_object_or_404(AcceleratorApplication, pk=pk, center_id=request.center_admin.center_id)
    milestone = get_object_or_404(AcceleratorMilestone, pk=milestone_pk, accelerator=application)
    milestone.delete()
    messages.success(request, f"Milestone '{milestone.title}' deleted.")
    return redirect("centeradmin:accelerator_view", pk=pk)


# ══════════════════════════════════════════════════════════════════════════════
# ACCELERATOR DOCUMENT MANAGEMENT
# ══════════════════════════════════════════════════════════════════════════════

@centeradmin_required
def accelerator_document_share(request, pk):
    """Share a document with an accelerator."""
    application = get_object_or_404(AcceleratorApplication, pk=pk, center_id=request.center_admin.center_id)

    if request.method == "POST":
        title = request.POST.get("title", "").strip()
        file  = request.FILES.get("file")

        if not title or not file:
            messages.error(request, "Title and file are required.")
        else:
            AcceleratorDocument.objects.create(
                accelerator=application,
                title=title,
                file=file,
                source="admin",
            )
            messages.success(request, f"Document '{title}' shared successfully.")
            return redirect("centeradmin:accelerator_view", pk=pk)

    return render(request, "centeradmin/accelerator_document_share.html", {
        "application": application,
        "center_admin": request.center_admin,
        "center": request.center_admin.center,
    })


@centeradmin_required
def accelerator_document_delete(request, pk, doc_pk):
    """Delete a shared document."""
    application = get_object_or_404(AcceleratorApplication, pk=pk, center_id=request.center_admin.center_id)
    document = get_object_or_404(AcceleratorDocument, pk=doc_pk, accelerator=application)
    document.delete()
    messages.success(request, "Document deleted.")
    return redirect("centeradmin:accelerator_view", pk=pk)


# ══════════════════════════════════════════════════════════════════════════════
# ACCELERATOR NOTICE MANAGEMENT
# ══════════════════════════════════════════════════════════════════════════════

@centeradmin_required
def accelerator_notice_post(request, pk):
    """Post a notice to an accelerator."""
    application = get_object_or_404(AcceleratorApplication, pk=pk, center_id=request.center_admin.center_id)

    if request.method == "POST":
        title = request.POST.get("title", "").strip()
        body = request.POST.get("body", "").strip()

        if not title or not body:
            messages.error(request, "Title and message are required.")
        else:
            AcceleratorNotice.objects.create(
                accelerator=application,
                title=title,
                body=body,
            )
            messages.success(request, f"Notice '{title}' posted successfully.")
            return redirect("centeradmin:accelerator_view", pk=pk)

    return render(request, "centeradmin/accelerator_notice_post.html", {
        "application": application,
        "center_admin": request.center_admin,
        "center": request.center_admin.center,
    })


@centeradmin_required
def accelerator_notice_delete(request, pk, notice_pk):
    """Delete a notice."""
    application = get_object_or_404(AcceleratorApplication, pk=pk, center_id=request.center_admin.center_id)
    notice = get_object_or_404(AcceleratorNotice, pk=notice_pk, accelerator=application)
    notice.delete()
    messages.success(request, "Notice deleted.")
    return redirect("centeradmin:accelerator_view", pk=pk)

def logout_view(request):
    logout(request)
    messages.info(request, "You have been logged out.")
    return redirect("centeradmin:login")
