from django.urls import path

from .views import (
    login_view,
    logout_view,
    dashboard_view,

    accelerator_edit,
    accelerator_list,
    accelerator_view,
    accelerator_create_credentials,
    accelerator_program_set,
    accelerator_milestone_add,
    accelerator_milestone_review,
    accelerator_milestone_delete,
    accelerator_document_share,
    accelerator_document_delete,
    accelerator_notice_post,
    accelerator_notice_delete,

    fellow_edit,
    fellow_list,
    fellow_view,
    fellow_create_credentials,
    internship_edit,
    internship_list,
    internship_view,
    internship_create_credentials,
    investor_edit,
    investor_list,
    investor_view,
    investor_create_credentials,
    mentor_edit,
    mentor_list,
    mentor_view,
    mentor_create_credentials,
    startup_edit,
    startup_list,
    startup_view,
    startup_create_credentials,
    vendor_edit,
    vendor_list,
    vendor_view,
    vendor_create_credentials,

)

app_name = "centeradmin"

urlpatterns = [
    path("login/", login_view, name="login"),
    path("dashboard/", dashboard_view, name="dashboard"),
    path("logout/", logout_view, name="logout"),

    path("startup-list/", startup_list, name="startup_list"),
    path("startup-view/<int:pk>/", startup_view, name="startup_view"),
    path("startup-edit/<int:pk>/", startup_edit, name="startup_edit"),
    path("startup-credentials/<int:pk>/", startup_create_credentials, name="startup_create_credentials"),

    path("accelerator-list/", accelerator_list, name="accelerator_list"),
    path("accelerator-view/<int:pk>/", accelerator_view, name="accelerator_view"),
    path("accelerator-edit/<int:pk>/", accelerator_edit, name="accelerator_edit"),
    path("accelerator-credentials/<int:pk>/", accelerator_create_credentials, name="accelerator_create_credentials"),
    
    path("accelerator-program/<int:pk>/", accelerator_program_set, name="accelerator_program_set"),
    path("accelerator-milestone-add/<int:pk>/", accelerator_milestone_add, name="accelerator_milestone_add"),
    path("accelerator-milestone-review/<int:pk>/<int:milestone_pk>/", accelerator_milestone_review, name="accelerator_milestone_review"),
    path("accelerator-milestone-delete/<int:pk>/<int:milestone_pk>/", accelerator_milestone_delete, name="accelerator_milestone_delete"),
    path("accelerator-document-share/<int:pk>/", accelerator_document_share, name="accelerator_document_share"),
    path("accelerator-document-delete/<int:pk>/<int:doc_pk>/", accelerator_document_delete, name="accelerator_document_delete"),
    path("accelerator-notice-post/<int:pk>/", accelerator_notice_post, name="accelerator_notice_post"),
    path("accelerator-notice-delete/<int:pk>/<int:notice_pk>/", accelerator_notice_delete, name="accelerator_notice_delete"),

    path("fellow-list/", fellow_list, name="fellow_list"),
    path("fellow-view/<int:pk>/", fellow_view, name="fellow_view"),
    path("fellow-edit/<int:pk>/", fellow_edit, name="fellow_edit"),
    path("fellow-credentials/<int:pk>/", fellow_create_credentials, name="fellow_create_credentials"),

    path("internship-list/", internship_list, name="internship_list"),
    path("internship-view/<int:pk>/", internship_view, name="internship_view"),
    path("internship-edit/<int:pk>/", internship_edit, name="internship_edit"),
    path("internship-credentials/<int:pk>/", internship_create_credentials, name="internship_create_credentials"),

    path("mentor-list/", mentor_list, name="mentor_list"),
    path("mentor-view/<int:pk>/", mentor_view, name="mentor_view"),
    path("mentor-edit/<int:pk>/", mentor_edit, name="mentor_edit"),
    path("mentor-credentials/<int:pk>/", mentor_create_credentials, name="mentor_create_credentials"),

    path("investor-list/", investor_list, name="investor_list"),
    path("investor-view/<int:pk>/", investor_view, name="investor_view"),
    path("investor-edit/<int:pk>/", investor_edit, name="investor_edit"),
    path("investor-credentials/<int:pk>/", investor_create_credentials, name="investor_create_credentials"),

    path("vendor-list/", vendor_list, name="vendor_list"),
    path("vendor-view/<int:pk>/", vendor_view, name="vendor_view"),
    path("vendor-edit/<int:pk>/", vendor_edit, name="vendor_edit"),
    path("vendor-credentials/<int:pk>/", vendor_create_credentials, name="vendor_create_credentials"),

]


