from django.shortcuts import render

from accounts.portal_auth import portal_required


fellow_required = portal_required("fellow")


@fellow_required
def dashboard(request):
    return render(request, "fellow/dashboard.html", {"fellow": request.fellow})
