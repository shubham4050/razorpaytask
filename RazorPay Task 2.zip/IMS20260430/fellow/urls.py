from django.urls import path
from .views import dashboard

app_name = "fellow"

urlpatterns = [
    path("dashboard/", dashboard, name="dashboard"),
    
    ]