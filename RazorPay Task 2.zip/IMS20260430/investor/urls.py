from django.urls import path
from .views import dashboard

app_name = "investor"

urlpatterns = [
    path("dashboard/", dashboard, name="dashboard"),
    
    ]