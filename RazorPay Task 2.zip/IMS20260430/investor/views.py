from django.shortcuts import render

from accounts.portal_auth import portal_required


investor_required = portal_required("investor")


@investor_required
def dashboard(request):
    return render(request, "investor/dashboard.html", {"investor": request.investor})
