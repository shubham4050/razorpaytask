from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ("applications", "0004_application_users"),
    ]

    operations = [
        migrations.RemoveField(model_name="acceleratorapplication", name="login_password"),
        migrations.RemoveField(model_name="fellowapplication", name="login_password"),
        migrations.RemoveField(model_name="internshipapplication", name="login_password"),
        migrations.RemoveField(model_name="investorapplication", name="login_password"),
        migrations.RemoveField(model_name="mentorapplication", name="login_password"),
        migrations.RemoveField(model_name="startupapplication", name="login_password"),
        migrations.RemoveField(model_name="vendorapplication", name="login_password"),
    ]
