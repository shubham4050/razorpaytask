from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


ROLE_MODELS = {
    "startup": ("StartupApplication", "startup_comp_name", "email", "startup_profile"),
    "accelerator": ("AcceleratorApplication", "startup_name", "email", "accelerator_profile"),
    "fellow": ("FellowApplication", "full_name", "email", "fellow_profile"),
    "internship": ("InternshipApplication", "full_name", "email", "internship_profile"),
    "mentor": ("MentorApplication", "full_name", "email", "mentor_profile"),
    "investor": ("InvestorApplication", "organization_name", "email", "investor_profile"),
    "vendor": ("VendorApplication", "company_name", "email", "vendor_profile"),
}


def build_auth_username(role, login_username):
    base = f"{role}:{login_username}"
    return base[:150]


def create_portal_users(apps, schema_editor):
    User = apps.get_model("auth", "User")
    Group = apps.get_model("auth", "Group")

    for role, (model_name, name_field, email_field, _related_name) in ROLE_MODELS.items():
        group, _ = Group.objects.get_or_create(name=role.replace("_", " ").title())
        Model = apps.get_model("applications", model_name)

        for profile in Model.objects.exclude(login_username="").exclude(login_password=""):
            username = build_auth_username(role, profile.login_username)
            user, _ = User.objects.get_or_create(username=username)
            user.password = profile.login_password
            user.email = getattr(profile, email_field, "") or ""
            user.first_name = (getattr(profile, name_field, "") or "")[:150]
            user.is_active = profile.status == "approved"
            user.save()
            user.groups.add(group)
            profile.user = user
            profile.save(update_fields=["user"])


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ("applications", "0003_acceleratorapplication_login_password_and_more"),
    ]

    operations = [
        migrations.AddField(
            model_name="acceleratorapplication",
            name="user",
            field=models.OneToOneField(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="accelerator_profile", to=settings.AUTH_USER_MODEL),
        ),
        migrations.AddField(
            model_name="fellowapplication",
            name="user",
            field=models.OneToOneField(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="fellow_profile", to=settings.AUTH_USER_MODEL),
        ),
        migrations.AddField(
            model_name="internshipapplication",
            name="user",
            field=models.OneToOneField(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="internship_profile", to=settings.AUTH_USER_MODEL),
        ),
        migrations.AddField(
            model_name="investorapplication",
            name="user",
            field=models.OneToOneField(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="investor_profile", to=settings.AUTH_USER_MODEL),
        ),
        migrations.AddField(
            model_name="mentorapplication",
            name="user",
            field=models.OneToOneField(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="mentor_profile", to=settings.AUTH_USER_MODEL),
        ),
        migrations.AddField(
            model_name="startupapplication",
            name="user",
            field=models.OneToOneField(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="startup_profile", to=settings.AUTH_USER_MODEL),
        ),
        migrations.AddField(
            model_name="vendorapplication",
            name="user",
            field=models.OneToOneField(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="vendor_profile", to=settings.AUTH_USER_MODEL),
        ),
        migrations.RunPython(create_portal_users, migrations.RunPython.noop),
    ]
