from django.conf import settings
from django.db import models

from superadmin.models import IncubationCenter


STATUS_CHOICES = (
    ("pending", "Pending"),
    ("approved", "Approved"),
    ("rejected", "Rejected"),
)

CATEGORY_CHOICES = (
    ("technology", "Technology"),
    ("health", "Health"),
    ("energy", "Energy"),
    ("it", "IT"),
    ("ai_ml_iot", "AI / ML / IoT"),
    ("food", "Food"),
    ("textile", "Textile"),
    ("defence", "Defence"),
    ("fintech", "Fintech"),
    ("any_other", "Any Other"),
)


class CenterLinkedApplication(models.Model):
    center = models.ForeignKey(
        IncubationCenter,
        on_delete=models.CASCADE,
        related_name="%(class)ss",
    )
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="pending")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        abstract = True
        ordering = ["-created_at"]


class StartupApplication(CenterLinkedApplication):
    COMPANY_CHOICES = (
        ("organization", "Organization"),
        ("company", "Company"),
        ("school", "School"),
        ("startup", "Startup"),
    )
    CATEGORY_CHOICES = CATEGORY_CHOICES

    ABOUT_CHOICES = (
        ("yes", "Yes"),
        ("no", "No"),
    )

    startup_comp_name = models.CharField(max_length=200)
    comp_choices = models.CharField(max_length=50, choices=COMPANY_CHOICES)
    founder_name = models.CharField(max_length=200)
    email = models.EmailField()
    category = models.CharField(max_length=100, choices=CATEGORY_CHOICES)
    facebook_link = models.URLField(blank=True)
    linked_link = models.URLField(blank=True)
    about_confirmation = models.CharField(max_length=20, choices=ABOUT_CHOICES)
    description = models.TextField(blank=True)
    start_up_details = models.TextField()
    start_up_image = models.ImageField(upload_to="startup_images/", blank=True)
    startup_website = models.URLField(blank=True)

    login_username = models.CharField(max_length=150, blank=True)
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="startup_profile",
    )

    def __str__(self):
        return self.startup_comp_name


class AcceleratorApplication(CenterLinkedApplication):
    CATEGORY_CHOICES = CATEGORY_CHOICES

    startup_name = models.CharField(max_length=200)
    founder_name = models.CharField(max_length=200)
    email = models.EmailField()
    category = models.CharField(max_length=100, choices=CATEGORY_CHOICES)
    contact_number = models.CharField(max_length=15)
    facebook_link = models.URLField(blank=True)
    linked_link = models.URLField(blank=True)
    one_line_description = models.CharField(max_length=255)
    startup_details = models.TextField()
    pitch_deck = models.FileField(upload_to="accelerator_pitch_decks/", blank=True)
    website = models.URLField(blank=True)
    source = models.CharField(max_length=255)

    login_username = models.CharField(max_length=150, blank=True)
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="accelerator_profile",
    )

    def __str__(self):
        return self.startup_name


class FellowApplication(CenterLinkedApplication):
    full_name = models.CharField(max_length=200)
    email = models.EmailField()
    phone_number = models.CharField(max_length=15)
    highest_qualification = models.CharField(max_length=200)
    specialization = models.CharField(max_length=200)
    statement_of_purpose = models.TextField()
    resume = models.FileField(upload_to="fellow_resumes/", blank=True)

    login_username = models.CharField(max_length=150, blank=True)
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="fellow_profile",
    )

    def __str__(self):
        return self.full_name


class InternshipApplication(CenterLinkedApplication):
    full_name = models.CharField(max_length=200)
    email = models.EmailField()
    phone_number = models.CharField(max_length=15)
    college_name = models.CharField(max_length=200)
    course_name = models.CharField(max_length=200)
    preferred_domain = models.CharField(max_length=200)
    duration_weeks = models.PositiveIntegerField()
    internship_interest = models.TextField()
    resume = models.FileField(upload_to="internship_resumes/", blank=True)

    login_username = models.CharField(max_length=150, blank=True)
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="internship_profile",
    )

    def __str__(self):
        return self.full_name


class MentorApplication(CenterLinkedApplication):
    full_name = models.CharField(max_length=200)
    email = models.EmailField()
    phone_number = models.CharField(max_length=15)
    expertise_area = models.CharField(max_length=200)
    current_organization = models.CharField(max_length=200)
    years_of_experience = models.PositiveIntegerField()
    linkedin_profile = models.URLField(blank=True)
    profile_summary = models.TextField()
    profile_document = models.FileField(upload_to="mentor_profiles/", blank=True)

    login_username = models.CharField(max_length=150, blank=True)
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="mentor_profile",
    )

    def __str__(self):
        return self.full_name


class InvestorApplication(CenterLinkedApplication):
    organization_name = models.CharField(max_length=200)
    contact_person = models.CharField(max_length=200)
    email = models.EmailField()
    phone_number = models.CharField(max_length=15)
    investment_focus = models.CharField(max_length=200)
    ticket_size = models.CharField(max_length=150)
    website = models.URLField(blank=True)
    investment_note = models.TextField()

    login_username = models.CharField(max_length=150, blank=True)
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="investor_profile",
    )

    def __str__(self):
        return self.organization_name


class VendorApplication(CenterLinkedApplication):
    company_name = models.CharField(max_length=200)
    contact_person = models.CharField(max_length=200)
    email = models.EmailField()
    phone_number = models.CharField(max_length=15)
    service_category = models.CharField(max_length=200)
    website = models.URLField(blank=True)
    service_details = models.TextField()
    company_profile = models.FileField(upload_to="vendor_profiles/", blank=True)

    login_username = models.CharField(max_length=150, blank=True)
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="vendor_profile",
    )

    def __str__(self):
        return self.company_name
