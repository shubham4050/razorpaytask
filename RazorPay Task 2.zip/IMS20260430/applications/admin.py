from django.contrib import admin

from accounts.auth_utils import sync_profile_user

from .models import (
    AcceleratorApplication,
    FellowApplication,
    InternshipApplication,
    InvestorApplication,
    MentorApplication,
    StartupApplication,
    VendorApplication,
)


class PortalApplicationAdmin(admin.ModelAdmin):
    role = None
    display_name_field = None

    def save_model(self, request, obj, form, change):
        super().save_model(request, obj, form, change)
        if obj.login_username and obj.user_id:
            sync_profile_user(
                obj,
                self.role,
                obj.login_username,
                email=getattr(obj, "email", ""),
                full_name=getattr(obj, self.display_name_field, ""),
                is_active=obj.status == "approved",
            )


@admin.register(StartupApplication)
class StartupApplicationAdmin(PortalApplicationAdmin):
    role = "startup"
    display_name_field = "startup_comp_name"
    list_display = ("startup_comp_name", "founder_name", "center", "category", "status", "created_at")
    list_filter = ("status", "category", "center")
    search_fields = ("startup_comp_name", "founder_name", "email")


@admin.register(AcceleratorApplication)
class AcceleratorApplicationAdmin(PortalApplicationAdmin):
    role = "accelerator"
    display_name_field = "startup_name"
    list_display = ("startup_name", "founder_name", "center", "category", "status", "created_at")
    list_filter = ("status", "category", "center")
    search_fields = ("startup_name", "founder_name", "email")


@admin.register(FellowApplication)
class FellowApplicationAdmin(PortalApplicationAdmin):
    role = "fellow"
    display_name_field = "full_name"
    list_display = ("full_name", "email", "center", "specialization", "status", "created_at")
    list_filter = ("status", "center")
    search_fields = ("full_name", "email", "specialization")


@admin.register(InternshipApplication)
class InternshipApplicationAdmin(PortalApplicationAdmin):
    role = "internship"
    display_name_field = "full_name"
    list_display = ("full_name", "college_name", "center", "preferred_domain", "status", "created_at")
    list_filter = ("status", "center")
    search_fields = ("full_name", "email", "college_name")


@admin.register(MentorApplication)
class MentorApplicationAdmin(PortalApplicationAdmin):
    role = "mentor"
    display_name_field = "full_name"
    list_display = ("full_name", "current_organization", "center", "expertise_area", "status", "created_at")
    list_filter = ("status", "center")
    search_fields = ("full_name", "email", "expertise_area")


@admin.register(InvestorApplication)
class InvestorApplicationAdmin(PortalApplicationAdmin):
    role = "investor"
    display_name_field = "organization_name"
    list_display = ("organization_name", "contact_person", "center", "investment_focus", "status", "created_at")
    list_filter = ("status", "center")
    search_fields = ("organization_name", "contact_person", "email")


@admin.register(VendorApplication)
class VendorApplicationAdmin(PortalApplicationAdmin):
    role = "vendor"
    display_name_field = "company_name"
    list_display = ("company_name", "contact_person", "center", "service_category", "status", "created_at")
    list_filter = ("status", "center")
    search_fields = ("company_name", "contact_person", "email")
