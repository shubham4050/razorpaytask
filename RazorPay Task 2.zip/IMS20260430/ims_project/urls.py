

from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path("pixelmaster/", admin.site.urls),
    path("", include("landingpage.urls")),
    path("accounts/", include("accounts.urls")),
    path("centeradmin/", include("centeradmin.urls")),
    path("superadmin/", include("superadmin.urls")),

    path("startup/", include("startup.urls")),
    path("accelerator/", include("accelerator.urls")),
    path("fellow/", include("fellow.urls")),      
    path("internship/", include("internship.urls")),  
    path("mentor/", include("mentor.urls")),      
    path("investor/", include("investor.urls")),    
    path("vendor/", include("vendor.urls")),

]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
