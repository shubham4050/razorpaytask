from django.contrib import admin

from accounts.auth_utils import sync_profile_user

from .models import AdvisoryBoardMember, CenterAdmin, IncubationCenter


@admin.register(IncubationCenter)
class IncubationCenterAdmin(admin.ModelAdmin):
    list_display = ("name", "city", "contact_email", "capacity", "status")
    search_fields = ("name", "city", "contact_email")
    list_filter = ("status", "city")


@admin.register(CenterAdmin)
class CenterAdminAdmin(admin.ModelAdmin):
    list_display = ("full_name", "email", "center", "status")
    search_fields = ("full_name", "email")
    list_filter = ("status", "center")

    def save_model(self, request, obj, form, change):
        super().save_model(request, obj, form, change)
        if obj.user_id:
            sync_profile_user(
                obj,
                "centeradmin",
                obj.email,
                email=obj.email,
                full_name=obj.full_name,
                is_active=obj.status == "active" and obj.center.status == "active",
            )


@admin.register(AdvisoryBoardMember)
class AdvisoryBoardMemberAdmin(admin.ModelAdmin):
    list_display = ("full_name", "email", "expertise", "center", "status")
    search_fields = ("full_name", "email", "expertise")
    list_filter = ("status", "center")
