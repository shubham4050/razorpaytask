from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


def build_auth_username(role, login_username):
    base = f"{role}:{login_username}"
    return base[:150]


def create_center_admin_users(apps, schema_editor):
    User = apps.get_model("auth", "User")
    Group = apps.get_model("auth", "Group")
    CenterAdmin = apps.get_model("superadmin", "CenterAdmin")

    group, _ = Group.objects.get_or_create(name="Center Admin")
    for center_admin in CenterAdmin.objects.exclude(login_password=""):
        username = build_auth_username("centeradmin", center_admin.email)
        user, _ = User.objects.get_or_create(username=username)
        user.password = center_admin.login_password
        user.email = center_admin.email
        user.first_name = center_admin.full_name[:150]
        user.is_active = center_admin.status == "active" and center_admin.center.status == "active"
        user.save()
        user.groups.add(group)
        center_admin.user = user
        center_admin.save(update_fields=["user"])


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ("superadmin", "0003_centeradmin_login_password"),
    ]

    operations = [
        migrations.AddField(
            model_name="centeradmin",
            name="user",
            field=models.OneToOneField(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="center_admin_profile", to=settings.AUTH_USER_MODEL),
        ),
        migrations.RunPython(create_center_admin_users, migrations.RunPython.noop),
    ]
