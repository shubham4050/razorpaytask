from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ("superadmin", "0004_centeradmin_user"),
    ]

    operations = [
        migrations.RemoveField(model_name="centeradmin", name="login_password"),
    ]
