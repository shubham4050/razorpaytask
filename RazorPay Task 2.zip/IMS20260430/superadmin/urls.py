from django.urls import path

from .views import (
    admin_add,
    admin_delete,
    admin_edit,
    admin_list,
    advisory_add,
    advisory_delete,
    advisory_edit,
    advisory_list,
    center_add,
    center_delete,
    center_edit,
    center_list,
    dashboard,
)

app_name = "superadmin"

urlpatterns = [
    path("", dashboard, name="dashboard"),
    path("centers/", center_list, name="center_list"),
    path("centers/add/", center_add, name="center_add"),
    path("centers/<int:pk>/edit/", center_edit, name="center_edit"),
    path("centers/<int:pk>/delete/", center_delete, name="center_delete"),
    path("admins/", admin_list, name="admin_list"),
    path("admins/add/", admin_add, name="admin_add"),
    path("admins/<int:pk>/edit/", admin_edit, name="admin_edit"),
    path("admins/<int:pk>/delete/", admin_delete, name="admin_delete"),
    path("advisory-board/", advisory_list, name="advisory_list"),
    path("advisory-board/add/", advisory_add, name="advisory_add"),
    path("advisory-board/<int:pk>/edit/", advisory_edit, name="advisory_edit"),
    path("advisory-board/<int:pk>/delete/", advisory_delete, name="advisory_delete"),
]
