from django.contrib.auth import get_user_model
from django.test import Client, TestCase

from .models import AdvisoryBoardMember, CenterAdmin, IncubationCenter


class SuperAdminViewTests(TestCase):
    def setUp(self):
        self.client = Client()
        self.superadmin = get_user_model().objects.create_user(
            username="superadmin@example.com",
            email="superadmin@example.com",
            password="Admin@123",
            is_staff=True,
            is_superuser=True,
        )
        self.client.force_login(self.superadmin)

        self.center = IncubationCenter.objects.create(
            name="VNIT Incubation Hub",
            city="Nagpur",
            contact_email="center@example.com",
            phone_number="9876543210",
            website_url="https://example.com",
            capacity=120,
            status="active",
        )

    def test_dashboard_opens(self):
        response = self.client.get("/superadmin/")
        self.assertEqual(response.status_code, 200)

    def test_center_add_works(self):
        response = self.client.post(
            "/superadmin/centers/add/",
            {
                "name": "PCCOE",
                "city": "Pune",
                "contact_email": "pccoe@example.com",
                "phone_number": "9123456789",
                "website_url": "https://pccoe.example.com",
                "capacity": "100",
                "status": "active",
            },
        )

        self.assertEqual(response.status_code, 302)
        self.assertTrue(IncubationCenter.objects.filter(name="PCCOE").exists())

    def test_admin_add_works(self):
        response = self.client.post(
            "/superadmin/admins/add/",
            {
                "full_name": "Center Admin",
                "email": "admin@example.com",
                "password": "Admin@123",
                "phone_number": "9123456789",
                "center": str(self.center.id),
                "status": "active",
            },
        )

        self.assertEqual(response.status_code, 302)
        center_admin = CenterAdmin.objects.get(email="admin@example.com")
        self.assertTrue(center_admin.user)
        self.assertTrue(center_admin.user.check_password("Admin@123"))

    def test_advisory_add_works(self):
        response = self.client.post(
            "/superadmin/advisory-board/add/",
            {
                "full_name": "Advisory Member",
                "email": "advisor@example.com",
                "expertise": "Funding",
                "center": str(self.center.id),
                "status": "active",
            },
        )

        self.assertEqual(response.status_code, 302)
        self.assertTrue(AdvisoryBoardMember.objects.filter(email="advisor@example.com").exists())
