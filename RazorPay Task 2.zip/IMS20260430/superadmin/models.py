from django.conf import settings
from django.db import models


class TimeStampedModel(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True


class IncubationCenter(TimeStampedModel):
    STATUS_CHOICES = [
        ("active", "Active"),
        ("inactive", "Inactive"),
        ("planning", "Planning"),
    ]

    name = models.CharField(max_length=150)
    city = models.CharField(max_length=120)
    contact_email = models.EmailField()
    phone_number = models.CharField(max_length=20)
    website_url = models.URLField(blank=True)
    capacity = models.PositiveIntegerField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="active")
    logo = models.ImageField(upload_to="centers/logos/", blank=True)

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return self.name

    @property
    def admin_count(self):
        return self.admins.count()

    @property
    def advisory_count(self):
        return self.advisory_members.count()


class CenterAdmin(TimeStampedModel):
    STATUS_CHOICES = [
        ("active", "Active"),
        ("inactive", "Inactive"),
    ]

    full_name = models.CharField(max_length=150)
    email = models.EmailField(unique=True)
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="center_admin_profile",
    )
    phone_number = models.CharField(max_length=20, blank=True)
    center = models.ForeignKey(
        IncubationCenter,
        on_delete=models.CASCADE,
        related_name="admins",
    )
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="active")

    class Meta:
        ordering = ["full_name"]

    def __str__(self):
        return self.full_name


class AdvisoryBoardMember(TimeStampedModel):
    STATUS_CHOICES = [
        ("active", "Active"),
        ("inactive", "Inactive"),
    ]

    full_name = models.CharField(max_length=150)
    email = models.EmailField(unique=True)
    expertise = models.CharField(max_length=150)
    center = models.ForeignKey(
        IncubationCenter,
        on_delete=models.CASCADE,
        related_name="advisory_members",
    )
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="active")

    class Meta:
        ordering = ["full_name"]

    def __str__(self):
        return self.full_name
