from functools import wraps

from django.contrib import messages
from django.core.paginator import Paginator
from django.db.models import Count, Q, Sum
from django.shortcuts import get_object_or_404, redirect, render

from accounts.auth_utils import sync_profile_user

from .models import AdvisoryBoardMember, CenterAdmin, IncubationCenter


PAGE_SIZE = 10


def superadmin_required(view_func):
    @wraps(view_func)
    def wrapper(request, *args, **kwargs):
        if not request.user.is_authenticated or not (request.user.is_staff or request.user.is_superuser):
            return redirect("accounts:login")
        return view_func(request, *args, **kwargs)

    return wrapper


def get_pagination_data(request, queryset):
    paginator = Paginator(queryset, PAGE_SIZE)
    page_obj = paginator.get_page(request.GET.get("page"))
    query_params = request.GET.copy()
    query_params.pop("page", None)
    query_string = query_params.urlencode()

    if paginator.count:
        serial_start = page_obj.start_index() - 1
    else:
        serial_start = 0

    return page_obj, query_string, serial_start


def get_center_by_id(center_id):
    if not center_id:
        return None
    return IncubationCenter.objects.filter(pk=center_id).first()


@superadmin_required
def dashboard(request):
    centers = (
        IncubationCenter.objects.annotate(
            admins_total=Count("admins"),
            advisory_total=Count("advisory_members"),
        )
        .order_by("name")[:5]
    )
    total_capacity = IncubationCenter.objects.aggregate(total=Sum("capacity"))["total"] or 0

    return render(
        request,
        "superadmin/dashboard.html",
        {
            "centers": centers,
            "total_centers": IncubationCenter.objects.count(),
            "total_admins": CenterAdmin.objects.count(),
            "advisory_members": AdvisoryBoardMember.objects.count(),
            "total_capacity": total_capacity,
            "active_centers": IncubationCenter.objects.filter(status="active").count(),
            "inactive_centers": IncubationCenter.objects.exclude(status="active").count(),
        },
    )


@superadmin_required
def center_list(request):
    q = request.GET.get("q", "").strip()
    status_filter = request.GET.get("status", "").strip()

    centers = IncubationCenter.objects.annotate(
        admins_total=Count("admins"),
        advisory_total=Count("advisory_members"),
    ).order_by("name")

    if q:
        centers = centers.filter(
            Q(name__icontains=q)
            | Q(city__icontains=q)
            | Q(contact_email__icontains=q)
            | Q(phone_number__icontains=q)
        )

    if status_filter:
        centers = centers.filter(status=status_filter)

    page_obj, query_string, serial_start = get_pagination_data(request, centers)

    return render(
        request,
        "superadmin/center_list.html",
        {
            "centers": page_obj,
            "page_obj": page_obj,
            "query_string": query_string,
            "serial_start": serial_start,
            "q": q,
            "status_filter": status_filter,
            "status_choices": IncubationCenter.STATUS_CHOICES,
        },
    )


@superadmin_required
def center_add(request):
    values = {
        "name": "",
        "city": "",
        "contact_email": "",
        "phone_number": "",
        "website_url": "",
        "capacity": "",
        "status": "active",
        "current_logo": "",
    }

    if request.method == "POST":
        values["name"] = request.POST.get("name", "").strip()
        values["city"] = request.POST.get("city", "").strip()
        values["contact_email"] = request.POST.get("contact_email", "").strip()
        values["phone_number"] = request.POST.get("phone_number", "").strip()
        values["website_url"] = request.POST.get("website_url", "").strip()
        values["capacity"] = request.POST.get("capacity", "").strip()
        values["status"] = request.POST.get("status", "active").strip() or "active"

        center = IncubationCenter.objects.create(
            name=values["name"],
            city=values["city"],
            contact_email=values["contact_email"],
            phone_number=values["phone_number"],
            website_url=values["website_url"],
            capacity=values["capacity"],
            status=values["status"],
        )

        if request.FILES.get("logo"):
            center.logo = request.FILES.get("logo")
            center.save()

        messages.success(request, "Incubation center added successfully.")
        return redirect("superadmin:center_list")

    return render(
        request,
        "superadmin/center_form.html",
        {
            "form_title": "Add Incubation Center",
            "submit_label": "Save",
            "values": values,
            "status_choices": IncubationCenter.STATUS_CHOICES,
        },
    )


@superadmin_required
def center_edit(request, pk):
    center = get_object_or_404(IncubationCenter, pk=pk)
    values = {
        "name": center.name,
        "city": center.city,
        "contact_email": center.contact_email,
        "phone_number": center.phone_number,
        "website_url": center.website_url,
        "capacity": center.capacity,
        "status": center.status,
        "current_logo": center.logo.url if center.logo else "",
    }

    if request.method == "POST":
        values["name"] = request.POST.get("name", "").strip()
        values["city"] = request.POST.get("city", "").strip()
        values["contact_email"] = request.POST.get("contact_email", "").strip()
        values["phone_number"] = request.POST.get("phone_number", "").strip()
        values["website_url"] = request.POST.get("website_url", "").strip()
        values["capacity"] = request.POST.get("capacity", "").strip()
        values["status"] = request.POST.get("status", "active").strip() or "active"
        values["current_logo"] = center.logo.url if center.logo else ""

        center.name = values["name"]
        center.city = values["city"]
        center.contact_email = values["contact_email"]
        center.phone_number = values["phone_number"]
        center.website_url = values["website_url"]
        center.capacity = values["capacity"]
        center.status = values["status"]

        if request.FILES.get("logo"):
            center.logo = request.FILES.get("logo")

        center.save()
        messages.success(request, "Incubation center updated successfully.")
        return redirect("superadmin:center_list")

    return render(
        request,
        "superadmin/center_form.html",
        {
            "form_title": "Edit Incubation Center",
            "submit_label": "Update",
            "values": values,
            "status_choices": IncubationCenter.STATUS_CHOICES,
            "center": center,
        },
    )


@superadmin_required
def center_delete(request, pk):
    center = get_object_or_404(IncubationCenter, pk=pk)

    if request.method == "POST":
        center.delete()
        messages.success(request, "Incubation center deleted successfully.")
        return redirect("superadmin:center_list")

    return render(
        request,
        "superadmin/confirm_delete.html",
        {
            "entity_name": "incubation center",
            "object_name": str(center),
            "cancel_url": "superadmin:center_list",
        },
    )


@superadmin_required
def admin_list(request):
    q = request.GET.get("q", "").strip()
    admins = CenterAdmin.objects.select_related("center").order_by("full_name")

    if q:
        admins = admins.filter(
            Q(full_name__icontains=q)
            | Q(email__icontains=q)
            | Q(phone_number__icontains=q)
            | Q(center__name__icontains=q)
        )

    page_obj, query_string, serial_start = get_pagination_data(request, admins)

    return render(
        request,
        "superadmin/admin_list.html",
        {
            "admins": page_obj,
            "page_obj": page_obj,
            "query_string": query_string,
            "serial_start": serial_start,
            "q": q,
        },
    )


@superadmin_required
def admin_add(request):
    centers = IncubationCenter.objects.order_by("name")
    if not centers.exists():
        messages.warning(request, "Please create an incubation center first.")
        return redirect("superadmin:center_add")

    values = {
        "full_name": "",
        "email": "",
        "password": "",
        "phone_number": "",
        "center": "",
        "status": "active",
    }

    if request.method == "POST":
        values["full_name"] = request.POST.get("full_name", "").strip()
        values["email"] = request.POST.get("email", "").strip()
        values["password"] = request.POST.get("password", "").strip()
        values["phone_number"] = request.POST.get("phone_number", "").strip()
        values["center"] = request.POST.get("center", "").strip()
        values["status"] = request.POST.get("status", "active").strip() or "active"

        center_admin = CenterAdmin.objects.create(
            full_name=values["full_name"],
            email=values["email"],
            phone_number=values["phone_number"],
            center=get_center_by_id(values["center"]),
            status=values["status"],
        )
        if values["password"]:
            sync_profile_user(
                center_admin,
                "centeradmin",
                center_admin.email,
                password=values["password"],
                email=center_admin.email,
                full_name=center_admin.full_name,
                is_active=center_admin.status == "active" and center_admin.center.status == "active",
            )
        messages.success(request, "Center admin added successfully.")
        return redirect("superadmin:admin_list")

    return render(
        request,
        "superadmin/admin_form.html",
        {
            "form_title": "Add Center Admin",
            "submit_label": "Save",
            "values": values,
            "centers": centers,
            "status_choices": CenterAdmin.STATUS_CHOICES,
            "password_required": True,
        },
    )


@superadmin_required
def admin_edit(request, pk):
    center_admin = get_object_or_404(CenterAdmin, pk=pk)
    centers = IncubationCenter.objects.order_by("name")
    values = {
        "full_name": center_admin.full_name,
        "email": center_admin.email,
        "password": "",
        "phone_number": center_admin.phone_number,
        "center": str(center_admin.center_id),
        "status": center_admin.status,
    }

    if request.method == "POST":
        values["full_name"] = request.POST.get("full_name", "").strip()
        values["email"] = request.POST.get("email", "").strip()
        values["password"] = request.POST.get("password", "").strip()
        values["phone_number"] = request.POST.get("phone_number", "").strip()
        values["center"] = request.POST.get("center", "").strip()
        values["status"] = request.POST.get("status", "active").strip() or "active"

        center_admin.full_name = values["full_name"]
        center_admin.email = values["email"]
        center_admin.phone_number = values["phone_number"]
        center_admin.center = get_center_by_id(values["center"])
        center_admin.status = values["status"]
        center_admin.save()
        sync_profile_user(
            center_admin,
            "centeradmin",
            center_admin.email,
            password=values["password"] or None,
            email=center_admin.email,
            full_name=center_admin.full_name,
            is_active=center_admin.status == "active" and center_admin.center.status == "active",
        )

        messages.success(request, "Center admin updated successfully.")
        return redirect("superadmin:admin_list")

    return render(
        request,
        "superadmin/admin_form.html",
        {
            "form_title": "Edit Center Admin",
            "submit_label": "Update",
            "values": values,
            "centers": centers,
            "status_choices": CenterAdmin.STATUS_CHOICES,
            "password_required": False,
        },
    )


@superadmin_required
def admin_delete(request, pk):
    center_admin = get_object_or_404(CenterAdmin, pk=pk)

    if request.method == "POST":
        center_admin.delete()
        messages.success(request, "Center admin deleted successfully.")
        return redirect("superadmin:admin_list")

    return render(
        request,
        "superadmin/confirm_delete.html",
        {
            "entity_name": "center admin",
            "object_name": str(center_admin),
            "cancel_url": "superadmin:admin_list",
        },
    )


@superadmin_required
def advisory_list(request):
    q = request.GET.get("q", "").strip()
    selected_center = request.GET.get("center", "").strip()
    members = AdvisoryBoardMember.objects.select_related("center").order_by("full_name")

    if q:
        members = members.filter(
            Q(full_name__icontains=q)
            | Q(email__icontains=q)
            | Q(expertise__icontains=q)
            | Q(center__name__icontains=q)
        )

    if selected_center:
        members = members.filter(center_id=selected_center)

    page_obj, query_string, serial_start = get_pagination_data(request, members)

    return render(
        request,
        "superadmin/advisory_list.html",
        {
            "members": page_obj,
            "page_obj": page_obj,
            "query_string": query_string,
            "serial_start": serial_start,
            "centers": IncubationCenter.objects.order_by("name"),
            "q": q,
            "selected_center": selected_center,
        },
    )


@superadmin_required
def advisory_add(request):
    centers = IncubationCenter.objects.order_by("name")
    if not centers.exists():
        messages.warning(request, "Please create an incubation center first.")
        return redirect("superadmin:center_add")

    values = {
        "full_name": "",
        "email": "",
        "expertise": "",
        "center": "",
        "status": "active",
    }

    if request.method == "POST":
        values["full_name"] = request.POST.get("full_name", "").strip()
        values["email"] = request.POST.get("email", "").strip()
        values["expertise"] = request.POST.get("expertise", "").strip()
        values["center"] = request.POST.get("center", "").strip()
        values["status"] = request.POST.get("status", "active").strip() or "active"

        AdvisoryBoardMember.objects.create(
            full_name=values["full_name"],
            email=values["email"],
            expertise=values["expertise"],
            center=get_center_by_id(values["center"]),
            status=values["status"],
        )
        messages.success(request, "Advisory board member added successfully.")
        return redirect("superadmin:advisory_list")

    return render(
        request,
        "superadmin/advisory_form.html",
        {
            "form_title": "Add Advisory Board Member",
            "submit_label": "Save",
            "values": values,
            "centers": centers,
            "status_choices": AdvisoryBoardMember.STATUS_CHOICES,
        },
    )


@superadmin_required
def advisory_edit(request, pk):
    member = get_object_or_404(AdvisoryBoardMember, pk=pk)
    centers = IncubationCenter.objects.order_by("name")
    values = {
        "full_name": member.full_name,
        "email": member.email,
        "expertise": member.expertise,
        "center": str(member.center_id),
        "status": member.status,
    }

    if request.method == "POST":
        values["full_name"] = request.POST.get("full_name", "").strip()
        values["email"] = request.POST.get("email", "").strip()
        values["expertise"] = request.POST.get("expertise", "").strip()
        values["center"] = request.POST.get("center", "").strip()
        values["status"] = request.POST.get("status", "active").strip() or "active"

        member.full_name = values["full_name"]
        member.email = values["email"]
        member.expertise = values["expertise"]
        member.center = get_center_by_id(values["center"])
        member.status = values["status"]
        member.save()

        messages.success(request, "Advisory board member updated successfully.")
        return redirect("superadmin:advisory_list")

    return render(
        request,
        "superadmin/advisory_form.html",
        {
            "form_title": "Edit Advisory Board Member",
            "submit_label": "Update",
            "values": values,
            "centers": centers,
            "status_choices": AdvisoryBoardMember.STATUS_CHOICES,
        },
    )


@superadmin_required
def advisory_delete(request, pk):
    member = get_object_or_404(AdvisoryBoardMember, pk=pk)

    if request.method == "POST":
        member.delete()
        messages.success(request, "Advisory board member deleted successfully.")
        return redirect("superadmin:advisory_list")

    return render(
        request,
        "superadmin/confirm_delete.html",
        {
            "entity_name": "advisory board member",
            "object_name": str(member),
            "cancel_url": "superadmin:advisory_list",
        },
    )
