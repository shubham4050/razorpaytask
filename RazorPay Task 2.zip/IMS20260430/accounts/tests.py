from django.test import TestCase
from django.urls import reverse

from applications.models import StartupApplication
from superadmin.models import IncubationCenter


class PortalAuthTests(TestCase):
    def setUp(self):
        self.center = IncubationCenter.objects.create(
            name="Test Center",
            city="Test City",
            contact_email="center@example.com",
            phone_number="9999999999",
            capacity=10,
        )

    def test_stale_or_unapproved_portal_session_is_cleared(self):
        startup = StartupApplication.objects.create(
            center=self.center,
            startup_comp_name="Pending Startup",
            comp_choices="startup",
            founder_name="Founder",
            email="founder@example.com",
            category="technology",
            about_confirmation="yes",
            start_up_details="Details",
            status="pending",
        )
        session = self.client.session
        session["startup_id"] = startup.id
        session["startup_id_name"] = startup.startup_comp_name
        session.save()

        response = self.client.get(reverse("startup:dashboard"))

        self.assertEqual(response.status_code, 302)
        self.assertTrue(response.url.startswith(reverse("accounts:portal_login")))
