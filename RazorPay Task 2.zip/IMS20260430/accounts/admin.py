from django.contrib import admin
from django.contrib.auth import get_user_model
from django.contrib.auth.admin import UserAdmin


User = get_user_model()


def clean_auth_username(username):
    if ":" in username:
        return username.split(":", 1)[1]
    return username


def role_from_username(username):
    if ":" in username:
        return username.split(":", 1)[0].replace("_", " ").title()
    return "Super Admin" if username == "admin" else ""


admin.site.unregister(User)


@admin.register(User)
class IMSUserAdmin(UserAdmin):
    list_display = (
        "clean_username",
        "role",
        "email",
        "first_name",
        "is_staff",
        "is_active",
    )
    list_display_links = ("clean_username",)
    search_fields = ("username", "email", "first_name", "last_name")
    readonly_fields = UserAdmin.readonly_fields + ("clean_username", "role")

    def clean_username(self, obj):
        return clean_auth_username(obj.username)

    clean_username.short_description = "Login username"
    clean_username.admin_order_field = "username"

    def role(self, obj):
        role = role_from_username(obj.username)
        if role:
            return role
        groups = list(obj.groups.values_list("name", flat=True))
        return ", ".join(groups) or "-"

    role.short_description = "Role"

    def get_readonly_fields(self, request, obj=None):
        readonly_fields = list(super().get_readonly_fields(request, obj))
        if obj and "email" not in readonly_fields:
            readonly_fields.append("email")
        if obj and ":" in obj.username and "username" not in readonly_fields:
            readonly_fields.append("username")
        return readonly_fields

    def get_fieldsets(self, request, obj=None):
        fieldsets = super().get_fieldsets(request, obj)
        if not obj:
            return fieldsets

        return (
            (
                "IMS Login",
                {
                    "fields": (
                        "clean_username",
                        "role",
                        "username",
                        "email",
                        "password",
                    )
                },
            ),
            *fieldsets[1:],
        )
