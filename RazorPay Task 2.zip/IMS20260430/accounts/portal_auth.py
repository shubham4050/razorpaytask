from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect

from applications.models import (
    AcceleratorApplication,
    FellowApplication,
    InternshipApplication,
    InvestorApplication,
    MentorApplication,
    StartupApplication,
    VendorApplication,
)


ROLE_CONFIG = {
    "startup": {
        "model": StartupApplication,
        "session_key": "startup_id",
        "name_field": "startup_comp_name",
        "dashboard": "startup:dashboard",
        "request_attr": "startup",
        "user_related_name": "startup_profile",
    },
    "accelerator": {
        "model": AcceleratorApplication,
        "session_key": "accelerator_id",
        "name_field": "startup_name",
        "dashboard": "accelerator:dashboard",
        "request_attr": "accelerator",
        "user_related_name": "accelerator_profile",
    },
    "fellow": {
        "model": FellowApplication,
        "session_key": "fellow_id",
        "name_field": "full_name",
        "dashboard": "fellow:dashboard",
        "request_attr": "fellow",
        "user_related_name": "fellow_profile",
    },
    "internship": {
        "model": InternshipApplication,
        "session_key": "internship_id",
        "name_field": "full_name",
        "dashboard": "internship:dashboard",
        "request_attr": "internship",
        "user_related_name": "internship_profile",
    },
    "mentor": {
        "model": MentorApplication,
        "session_key": "mentor_id",
        "name_field": "full_name",
        "dashboard": "mentor:dashboard",
        "request_attr": "mentor",
        "user_related_name": "mentor_profile",
    },
    "investor": {
        "model": InvestorApplication,
        "session_key": "investor_id",
        "name_field": "organization_name",
        "dashboard": "investor:dashboard",
        "request_attr": "investor",
        "user_related_name": "investor_profile",
    },
    "vendor": {
        "model": VendorApplication,
        "session_key": "vendor_id",
        "name_field": "company_name",
        "dashboard": "vendor:dashboard",
        "request_attr": "vendor",
        "user_related_name": "vendor_profile",
    },
}


def get_portal_record(request, role):
    if not request.user.is_authenticated:
        return None

    cfg = ROLE_CONFIG[role]
    try:
        record = getattr(request.user, cfg["user_related_name"])
    except cfg["model"].DoesNotExist:
        return None

    if record.status != "approved":
        return None

    return record


def portal_required(role):
    cfg = ROLE_CONFIG[role]

    def decorator(view_func):
        @login_required(login_url="accounts:portal_login")
        def wrapper(request, *args, **kwargs):
            record = get_portal_record(request, role)
            if not record:
                messages.error(request, "Please log in with an approved portal account.")
                return redirect("accounts:portal_login")

            setattr(request, cfg["request_attr"], record)
            return view_func(request, *args, **kwargs)

        return wrapper

    return decorator
