from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group


ROLE_GROUPS = {
    "superadmin": "Super Admin",
    "centeradmin": "Center Admin",
    "startup": "Startup",
    "accelerator": "Accelerator",
    "fellow": "Fellow",
    "internship": "Internship",
    "mentor": "Mentor",
    "investor": "Investor",
    "vendor": "Vendor",
}


def build_auth_username(role, login_username):
    base = f"{role}:{login_username}"
    if len(base) <= 150:
        return base
    return base[:150]


def assign_role_group(user, role):
    group_name = ROLE_GROUPS[role]
    group, _ = Group.objects.get_or_create(name=group_name)
    user.groups.add(group)


def sync_profile_user(profile, role, username, password=None, email="", full_name="", is_active=True):
    User = get_user_model()
    auth_username = build_auth_username(role, username)

    user = profile.user if getattr(profile, "user_id", None) else None
    if user is None:
        user, _ = User.objects.get_or_create(username=auth_username)

    user.username = auth_username
    user.email = email or ""
    user.first_name = full_name[:150] if full_name else ""
    user.is_active = is_active

    if password:
        user.set_password(password)

    user.save()
    assign_role_group(user, role)

    if profile.user_id != user.id:
        profile.user = user
        profile.save(update_fields=["user"])

    return user
