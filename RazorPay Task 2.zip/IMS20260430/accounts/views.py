from django.contrib import messages
from django.contrib.auth import authenticate, get_user_model, login, logout
from django.shortcuts import redirect, render

from accounts.auth_utils import build_auth_username
from accounts.portal_auth import ROLE_CONFIG


def _authenticate_by_username_or_email(request, email, password):
    user = authenticate(request, username=email, password=password)
    if user:
        return user

    User = get_user_model()
    users = User.objects.filter(email=email)
    for candidate in users:
        user = authenticate(request, username=candidate.username, password=password)
        if user:
            return user

    return None


def login_view(request):
    if request.user.is_authenticated and (request.user.is_staff or request.user.is_superuser):
        return redirect("superadmin:dashboard")

    if request.method == "POST":
        role = request.POST.get("role", "super_admin").strip()
        email = request.POST.get("email", "").strip()
        password = request.POST.get("password", "").strip()

        if role != "super_admin":
            messages.error(request, "Please select the correct role.")
        elif not email or not password:
            messages.error(request, "Email and password are required.")
        else:
            user = _authenticate_by_username_or_email(request, email, password)
            if not user or not (user.is_staff or user.is_superuser):
                messages.error(request, "Invalid super admin credentials.")
            else:
                login(request, user)
                return redirect("superadmin:dashboard")

        return render(request, "accounts/login.html", {"email_value": email})

    return render(request, "accounts/login.html")


def logout_view(request):
    logout(request)
    messages.info(request, "You have been logged out.")
    return redirect("accounts:login")


def portal_login_view(request):
    for role, cfg in ROLE_CONFIG.items():
        if request.user.is_authenticated and hasattr(request.user, cfg["user_related_name"]):
            record = getattr(request.user, cfg["user_related_name"])
            if record.status == "approved":
                return redirect(cfg["dashboard"])

    if request.method == "POST":
        role = request.POST.get("role", "").strip()
        username = request.POST.get("username", "").strip()
        password = request.POST.get("password", "").strip()

        if not role or role not in ROLE_CONFIG:
            messages.error(request, "Please select a valid role.")
        elif not username or not password:
            messages.error(request, "Username and password are required.")
        else:
            cfg = ROLE_CONFIG[role]
            record = cfg["model"].objects.filter(login_username=username).first()

            if not record:
                messages.error(request, "Invalid username or password.")
            elif record.status != "approved":
                messages.error(request, "Your application is not approved yet.")
            if "record" in locals() and record and record.status == "approved":
                auth_username = build_auth_username(role, username)
                user = authenticate(request, username=auth_username, password=password)
                if not user:
                    messages.error(request, "Invalid username or password.")
                elif not record.user_id or record.user_id != user.id:
                    messages.error(request, "This login is not linked to the selected role.")
                else:
                    login(request, user)
                    request.session["portal_role"] = role
                    return redirect(cfg["dashboard"])

        return render(
            request,
            "accounts/portal_login.html",
            {
                "username_value": username,
                "selected_role": role,
            },
        )

    return render(request, "accounts/portal_login.html")


def portal_logout_view(request):
    logout(request)
    messages.info(request, "You have been logged out.")
    return redirect("accounts:portal_login")
