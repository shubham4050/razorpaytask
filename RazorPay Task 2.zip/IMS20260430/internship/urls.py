from django.urls import path
from .views import dashboard

app_name = "internship"

urlpatterns = [
    path("dashboard/", dashboard, name="dashboard"),
    
    ]