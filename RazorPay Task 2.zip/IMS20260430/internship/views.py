from django.shortcuts import render

from accounts.portal_auth import portal_required


internship_required = portal_required("internship")


@internship_required
def dashboard(request):
    return render(request, "internship/dashboard.html", {"internship": request.internship})
