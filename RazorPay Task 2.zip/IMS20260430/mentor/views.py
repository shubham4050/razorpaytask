from django.shortcuts import render

from accounts.portal_auth import portal_required


mentor_required = portal_required("mentor")


@mentor_required
def dashboard(request):
    return render(request, "mentor/dashboard.html", {"mentor": request.mentor})
