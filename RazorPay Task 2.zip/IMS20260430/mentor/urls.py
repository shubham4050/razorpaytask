from django.urls import path
from .views import dashboard

app_name = "mentor"

urlpatterns = [
    path("dashboard/", dashboard, name="dashboard"),
    
    ]