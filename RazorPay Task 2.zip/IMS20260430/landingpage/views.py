from django.shortcuts import get_object_or_404, render

from applications.models import (
    AcceleratorApplication,
    FellowApplication,
    InternshipApplication,
    InvestorApplication,
    MentorApplication,
    StartupApplication,
    VendorApplication,
)
from superadmin.models import IncubationCenter


def active_centers():
    return IncubationCenter.objects.filter(status="active").order_by("name")


def success_response(request, module_name):
    return render(request, "applications/application_success.html", {"module_name": module_name})


def home(request):
    module_cards = [
        {"title": "Startup", "subtitle": "Startup intake form", "url_name": "apply_startup", "icon": "rocket"},
        {"title": "Accelerator", "subtitle": "Acceleration program form", "url_name": "apply_accelerator", "icon": "bolt"},
        {"title": "Fellow", "subtitle": "Fellowship application form", "url_name": "apply_fellow", "icon": "graduation-cap"},
        {"title": "Internship", "subtitle": "Internship request form", "url_name": "apply_internship", "icon": "briefcase"},
        {"title": "Mentor", "subtitle": "Mentor onboarding form", "url_name": "apply_mentor", "icon": "users"},
        {"title": "Investor", "subtitle": "Investor interest form", "url_name": "apply_investor", "icon": "line-chart"},
        {"title": "Vendor", "subtitle": "Vendor registration form", "url_name": "apply_vendor", "icon": "building"},
    ]
    return render(request, "landingpage/home.html", {"module_cards": module_cards, "center_total": active_centers().count()})


def startup_details(request):
    return render(request, 'landingpage/startup_details.html')

def accelerator_details(request):
    return render(request, 'landingpage/accelerator_details.html')

def fellow_details(request):
    return render(request, 'landingpage/fellow_details.html')

def internship_details(request):
    return render(request, 'landingpage/internship_details.html')

def mentor_details(request):
    return render(request, 'landingpage/mentor_details.html')

def investor_details(request):
    return render(request, 'landingpage/investor_details.html')

def vendor_details(request):
    return render(request, 'landingpage/vendor_details.html')

def about(request):
    return render(request, 'landingpage/about.html')

def contact(request):
    return render(request, 'landingpage/contact.html')

def apply_startup(request):
    context = {
        "centers": active_centers(),
        "comp_choices": StartupApplication.COMPANY_CHOICES,
        "about_choices": StartupApplication.ABOUT_CHOICES,
        "category_choices": StartupApplication.CATEGORY_CHOICES,
    }

    if request.method == "POST":
        StartupApplication.objects.create(
            center_id=request.POST.get("center"),
            startup_comp_name=request.POST.get("startup_comp_name"),
            comp_choices=request.POST.get("comp_choices"),
            founder_name=request.POST.get("founder_name"),
            email=request.POST.get("email"),
            category=request.POST.get("category"),
            facebook_link=request.POST.get("facebook_link", "").strip(),
            linked_link=request.POST.get("linked_link", "").strip(),
            about_confirmation=request.POST.get("about_confirmation"),
            description=request.POST.get("description", "").strip(),
            start_up_details=request.POST.get("start_up_details"),
            start_up_image=request.FILES.get("start_up_image"),
            startup_website=request.POST.get("startup_website", "").strip(),
        )
        return success_response(request, "Startup")

    return render(request, "landingpage/apply_startup.html", context)


def apply_accelerator(request):
    context = {
        "centers": active_centers(),
        "category_choices": AcceleratorApplication.CATEGORY_CHOICES,
    }

    if request.method == "POST":
        center = get_object_or_404(IncubationCenter, pk=request.POST.get("center"), status="active")
        AcceleratorApplication.objects.create(
            center=center,
            startup_name=request.POST.get("startup_name"),
            founder_name=request.POST.get("founder_name"),
            email=request.POST.get("email"),
            category=request.POST.get("category"),
            contact_number=request.POST.get("contact_number"),
            facebook_link=request.POST.get("facebook_link", "").strip(),
            linked_link=request.POST.get("linked_link", "").strip(),
            one_line_description=request.POST.get("one_line_description"),
            startup_details=request.POST.get("startup_details"),
            pitch_deck=request.FILES.get("pitch_deck"),
            website=request.POST.get("website", "").strip(),
            source=request.POST.get("source"),
        )
        return success_response(request, "Accelerator")

    return render(request, "landingpage/apply_accelerator.html", context)


def apply_fellow(request):
    context = {"centers": active_centers()}

    if request.method == "POST":
        FellowApplication.objects.create(
            center_id=request.POST.get("center"),
            full_name=request.POST.get("full_name"),
            email=request.POST.get("email"),
            phone_number=request.POST.get("phone_number"),
            highest_qualification=request.POST.get("highest_qualification"),
            specialization=request.POST.get("specialization"),
            statement_of_purpose=request.POST.get("statement_of_purpose"),
            resume=request.FILES.get("resume"),
        )
        return success_response(request, "Fellow")

    return render(request, "landingpage/apply_fellow.html", context)


def apply_internship(request):
    context = {"centers": active_centers()}

    if request.method == "POST":
        InternshipApplication.objects.create(
            center_id=request.POST.get("center"),
            full_name=request.POST.get("full_name"),
            email=request.POST.get("email"),
            phone_number=request.POST.get("phone_number"),
            college_name=request.POST.get("college_name"),
            course_name=request.POST.get("course_name"),
            preferred_domain=request.POST.get("preferred_domain"),
            duration_weeks=request.POST.get("duration_weeks"),
            internship_interest=request.POST.get("internship_interest"),
            resume=request.FILES.get("resume"),
        )
        return success_response(request, "Internship")

    return render(request, "landingpage/apply_internship.html", context)


def apply_mentor(request):
    context = {"centers": active_centers()}

    if request.method == "POST":
        MentorApplication.objects.create(
            center_id=request.POST.get("center"),
            full_name=request.POST.get("full_name"),
            email=request.POST.get("email"),
            phone_number=request.POST.get("phone_number"),
            expertise_area=request.POST.get("expertise_area"),
            current_organization=request.POST.get("current_organization"),
            years_of_experience=request.POST.get("years_of_experience"),
            linkedin_profile=request.POST.get("linkedin_profile", "").strip(),
            profile_summary=request.POST.get("profile_summary"),
            profile_document=request.FILES.get("profile_document"),
        )
        return success_response(request, "Mentor")

    return render(request, "landingpage/apply_mentor.html", context)


def apply_investor(request):
    context = {"centers": active_centers()}

    if request.method == "POST":
        InvestorApplication.objects.create(
            center_id=request.POST.get("center"),
            organization_name=request.POST.get("organization_name"),
            contact_person=request.POST.get("contact_person"),
            email=request.POST.get("email"),
            phone_number=request.POST.get("phone_number"),
            investment_focus=request.POST.get("investment_focus"),
            ticket_size=request.POST.get("ticket_size"),
            website=request.POST.get("website", "").strip(),
            investment_note=request.POST.get("investment_note"),
        )
        return success_response(request, "Investor")

    return render(request, "landingpage/apply_investor.html", context)


def apply_vendor(request):
    context = {"centers": active_centers()}

    if request.method == "POST":
        VendorApplication.objects.create(
            center_id=request.POST.get("center"),
            company_name=request.POST.get("company_name"),
            contact_person=request.POST.get("contact_person"),
            email=request.POST.get("email"),
            phone_number=request.POST.get("phone_number"),
            service_category=request.POST.get("service_category"),
            website=request.POST.get("website", "").strip(),
            service_details=request.POST.get("service_details"),
            company_profile=request.FILES.get("company_profile"),
        )
        return success_response(request, "Vendor")

    return render(request, "landingpage/apply_vendor.html", context)
