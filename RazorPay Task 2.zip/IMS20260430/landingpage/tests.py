from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase

from applications.models import AcceleratorApplication, StartupApplication
from superadmin.models import IncubationCenter


class LandingPageTests(TestCase):
    def setUp(self):
        self.center = IncubationCenter.objects.create(
            name="VNIT Incubation Hub",
            city="Nagpur",
            contact_email="center@example.com",
            phone_number="9876543210",
            website_url="https://example.com",
            capacity=120,
            status="active",
        )

    def test_home_page_opens(self):
        response = self.client.get("/")
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Choose Your Application Type")

    def test_startup_form_saves_image(self):
        image_file = SimpleUploadedFile("logo.png", b"fake-image-content", content_type="image/png")
        response = self.client.post(
            "/apply/startup/",
            {
                "center": str(self.center.id),
                "startup_comp_name": "Nova Labs",
                "comp_choices": "startup",
                "founder_name": "Asha Patil",
                "email": "asha@example.com",
                "category": "technology",
                "facebook_link": "",
                "linked_link": "",
                "about_confirmation": "yes",
                "description": "AI platform",
                "start_up_details": "Detailed startup summary",
                "startup_website": "https://example.com",
                "start_up_image": image_file,
            },
        )

        self.assertEqual(response.status_code, 200)
        self.assertTrue(StartupApplication.objects.filter(startup_comp_name="Nova Labs").exists())
        self.assertTrue(StartupApplication.objects.get(startup_comp_name="Nova Labs").start_up_image)

    def test_accelerator_form_saves_pitch_deck(self):
        pitch_deck = SimpleUploadedFile("pitch.pdf", b"pitch deck", content_type="application/pdf")
        response = self.client.post(
            "/apply/accelerator/",
            {
                "center": str(self.center.id),
                "startup_name": "Nova Accelerator",
                "founder_name": "Rohit Sharma",
                "email": "rohit@example.com",
                "category": "technology",
                "contact_number": "9876543210",
                "facebook_link": "",
                "linked_link": "https://linkedin.com/company/nova",
                "one_line_description": "Growth accelerator",
                "startup_details": "Accelerator details",
                "website": "https://nova.example.com",
                "source": "Referral",
                "pitch_deck": pitch_deck,
            },
        )

        self.assertEqual(response.status_code, 200)
        self.assertTrue(AcceleratorApplication.objects.filter(startup_name="Nova Accelerator").exists())
        self.assertTrue(AcceleratorApplication.objects.get(startup_name="Nova Accelerator").pitch_deck)
