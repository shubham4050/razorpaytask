from django.urls import path

from . import views

urlpatterns = [
    path("", views.home, name="home"),

    path("startup/details/", views.startup_details, name="startup_details"),
    path("accelerator/details/", views.accelerator_details, name="accelerator_details"),
    path("fellow/details/", views.fellow_details, name="fellow_details"),
    path("internship/details/", views.internship_details, name="internship_details"),
    path("mentor/details/", views.mentor_details, name="mentor_details"),
    path("investor/details/", views.investor_details, name="investor_details"),
    path("vendor/details/", views.vendor_details, name="vendor_details"),

    path("apply/startup/", views.apply_startup, name="apply_startup"),
    path("apply/accelerator/", views.apply_accelerator, name="apply_accelerator"),
    path("apply/fellow/", views.apply_fellow, name="apply_fellow"),
    path("apply/internship/", views.apply_internship, name="apply_internship"),
    path("apply/mentor/", views.apply_mentor, name="apply_mentor"),
    path("apply/investor/", views.apply_investor, name="apply_investor"),
    path("apply/vendor/", views.apply_vendor, name="apply_vendor"),

    path("about/", views.about, name="about"),
    path("contact/", views.contact, name="contact"),


]
