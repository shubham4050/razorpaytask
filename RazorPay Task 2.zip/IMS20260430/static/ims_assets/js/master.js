

//Add Row Table
$(document).ready(function () {
  function resetSerialNumbers() {
    $('#tblCustomers2 tbody tr').each(function (index) {
      $(this).find('td:first').text(index + 1);
    });
  }

  var index = 2;
  var total_rows = 1;
  $('#add-row').on('click', function (e) {
    e.preventDefault();
    console.log(index);

    const newRow = `
                        <tr>
                            <td>${index}</td>
							<td><input type="text" name="doc_name_${index}" maxlength="100" required/></td>
							<td>
								<span>
									<label for="document_${index}" class="Browse-btn-grad" data-default="Upload File"><i class="fa fa-upload"></i></label>
									<input id="document_${index}" type="file" name="document_${index}" class="doc-file" data-filename="">
								</span>
							</td>

							<td><input class="remove-btn" type='button' value='\uD83D\uDDD1' /></td>
						</tr>
					`;

    if (total_rows < 5) {
      $('#tblCustomers2 tbody').append(newRow);
      index++;
      total_rows++;

      $("#row_count").val(index);
    }
    else {
      alert('You can not allow to add more than 5 records.')
    }
    resetSerialNumbers();

  });

  $('#tblCustomers2').on('click', '.remove-btn', function () {
    if (confirm('Are you sure you want to remove this row?')) {
      const row = $(this).closest('tr')[0]; // Get the closest row element
      if (total_rows <= 1) {
        alert("Atleast add one Award.")
      }
      else {
        const table = document.getElementById('tblCustomers2').getElementsByTagName('tbody')[0];
        table.deleteRow(row.rowIndex - 1);
        total_rows--;
      }
    }

    resetSerialNumbers();
  });

  $('#tblCustomers2').on('change', '.doc-file', function () {
    const fileInput = this;
    const fileId = $(fileInput).attr('id');
    const label = $('label[for="' + fileId + '"]');

    if (fileInput.files.length > 0) {
      const fileName = fileInput.files[0].name;
      const shortName = fileName.length > 10 ? fileName.slice(0, 5) + "..." : fileName;
      label.text(shortName);
    } else {
      label.html('<i class="fa fa-upload"></i>')
    }
  });
});


const body = document.querySelector("body");
const sidebar = document.querySelector(".sidebar");
const submenuItems = document.querySelectorAll(".submenu_item");
const sidebarOpen = document.querySelector("#sidebarOpen");
const sidebarClose = document.querySelector(".collapse_sidebar");
const sidebarExpand = document.querySelector(".expand_sidebar");
sidebarOpen.addEventListener("click", () => sidebar.classList.toggle("close"));

// document.addEventListener('DOMContentLoaded', () => {
//     const element = document.getElementById('sidebarOpen'); // Ensure this ID exists
//     if (element) {
//         element.addEventListener('click', () => {
//             console.log('Clicked');
//         });
//     }
// });


submenuItems.forEach((item, index) => {
  item.addEventListener("click", () => {
    item.classList.toggle("show_submenu");
    submenuItems.forEach((item2, index2) => {
      if (index !== index2) {
        item2.classList.remove("show_submenu");
      }
    });
  });
});




if (window.innerWidth < 992) {
  sidebar.classList.add("close");
} else {
  sidebar.classList.remove("close");
}


// Active Class
$(function () {
  var url = window.location.href;

  $(".sidebar a").each(function () {
    if (url == (this.href)) {
      $(this).closest("li").addClass("active");
    }
  });
});


// Function to show popup
function togglePopup(p) {

  if (p == null) {
    $(".Popup-Container").toggle();
  }
  else {
    $(".Popup-Container1").toggle();
  }

}


