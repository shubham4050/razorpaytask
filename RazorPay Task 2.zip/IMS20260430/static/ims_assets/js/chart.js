


// Pie Chart start
        var xValues = ["Male", "Female"];
        var yValues = ["24", "60"];
        var barColors = [
            "green",
            "orange",
        ];

        new Chart("TotalMaleFemale", {
            type: "pie",
            data: {
                labels: xValues,
                datasets: [{
                    backgroundColor: barColors,
                    data: yValues
                }]
            },

        });
        // Pie Chart End
// End Pie Chart

