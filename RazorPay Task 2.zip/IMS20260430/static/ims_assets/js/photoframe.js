// -----Crop Image file upload with modal--

var $uploadCrop,
    tempFilename,
    rawImg,
    imageId;

function readFile(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();
        reader.onload = function (e) {
            $('.upload-demo').addClass('ready');
            $('#cropImagePop').modal('show');
            rawImg = e.target.result;
        }
        reader.readAsDataURL(input.files[0]);
    }
    else {
        console.log("Sorry - you're browser doesn't support the FileReader API");
    }
}

$uploadCrop = $('#upload-demo').croppie({
    viewport: {
        width: 160,
        height: 160,
        type: 'square'
    },
    enforceBoundary: false,
    enableExif: true
});

$('#cropImagePop').on('shown.bs.modal', function(){
    $('.cr-slider-wrap').prepend('<p>Image Zoom</p>');
    $uploadCrop.croppie('bind', {
        url: rawImg
    }).then(function(){
        console.log('jQuery bind complete');
    });
});

$('#cropImagePop').on('hidden.bs.modal', function(){
    $('.item-img').val('');  // Reset file input
    $('.cr-slider-wrap p').remove();
});

$('.item-img').on('change', function () { 
    readFile(this); 
});

$('.replacePhoto').on('click', function(){
    $('#cropImagePop').modal('hide');
    $('.item-img').trigger('click');
})

$('#cropImageBtn').on('click', function (ev) {
    $uploadCrop.croppie('result', {
        type: 'base64',
        backgroundColor : "#000000",
        format: 'png',
        size: {width: 160, height: 160}
    }).then(function (resp) {
        // Update the preview image
        $('#item-img-output').attr('src', resp);
        $('#cropImagePop').modal('hide');

        // Convert the base64 string to a Blob and create a File object
        var byteString = atob(resp.split(',')[1]);  // Decode base64 image
        var ab = new ArrayBuffer(byteString.length);
        var ia = new Uint8Array(ab);

        // Convert base64 string to binary string (ArrayBuffer)
        for (var i = 0; i < byteString.length; i++) {
            ia[i] = byteString.charCodeAt(i);
        }

        // Create a Blob from the binary string
        var blob = new Blob([ab], { type: 'image/png' });

        // Create a File object (simulating the file input)
        var registration_no = document.getElementById('registration_no');
		
		if (!registration_no || !registration_no.value) {
			registration_no = { value: 'cropped_image' };
		}
		else{
			var registration_no = document.getElementById('registration_no');

		}
        var filename = registration_no.value + '.png';

        var file = new File([blob], filename, { type: 'image/png' });

        // Create a DataTransfer object to simulate the file input change event
        var dataTransfer = new DataTransfer();
        dataTransfer.items.add(file);

        // Assign the file to the input element
        $('#photo')[0].files = dataTransfer.files;

        // Trigger change event to notify the form of the file selection
        $('#photo').trigger('change');
        
        // Optionally hide the modal after processing
        $('#cropImagePop').modal('hide');

        // $('.hideElements').removeClass('hideElements');
        $(".Common-Btn-disabled").prop('disabled', false).removeClass('Common-Btn-disabled');
    });
});
