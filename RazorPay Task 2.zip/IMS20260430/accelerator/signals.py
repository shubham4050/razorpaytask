from django.db.models.signals import post_save
from django.dispatch import receiver

from applications.models import AcceleratorApplication

from .models import AcceleratorProgram


@receiver(post_save, sender=AcceleratorApplication)
def create_program_for_approved_accelerator(sender, instance, **kwargs):
    if instance.status == "approved":
        AcceleratorProgram.objects.get_or_create(accelerator=instance)
