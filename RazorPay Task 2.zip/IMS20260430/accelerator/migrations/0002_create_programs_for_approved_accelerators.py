from django.db import migrations


def create_programs_for_approved_accelerators(apps, schema_editor):
    AcceleratorApplication = apps.get_model("applications", "AcceleratorApplication")
    AcceleratorProgram = apps.get_model("accelerator", "AcceleratorProgram")

    for application in AcceleratorApplication.objects.filter(status="approved"):
        AcceleratorProgram.objects.get_or_create(accelerator=application)


def remove_blank_auto_created_programs(apps, schema_editor):
    AcceleratorProgram = apps.get_model("accelerator", "AcceleratorProgram")
    AcceleratorProgram.objects.filter(
        program_name="",
        batch_name="",
        start_date__isnull=True,
        end_date__isnull=True,
        current_stage="",
        notes="",
    ).delete()


class Migration(migrations.Migration):

    dependencies = [
        ("accelerator", "0001_initial"),
    ]

    operations = [
        migrations.RunPython(
            create_programs_for_approved_accelerators,
            remove_blank_auto_created_programs,
        ),
    ]
