from django.test import TestCase

from accelerator.models import AcceleratorProgram
from applications.models import AcceleratorApplication
from superadmin.models import IncubationCenter


class AcceleratorProgramTests(TestCase):
    def setUp(self):
        self.center = IncubationCenter.objects.create(
            name="Test Center",
            city="Test City",
            contact_email="center@example.com",
            phone_number="9999999999",
            capacity=10,
        )

    def test_program_is_created_when_accelerator_is_approved(self):
        application = AcceleratorApplication.objects.create(
            center=self.center,
            startup_name="Growth Startup",
            founder_name="Founder",
            email="founder@example.com",
            category="technology",
            contact_number="9999999999",
            one_line_description="One line",
            startup_details="Details",
            source="Referral",
            status="pending",
        )

        self.assertFalse(AcceleratorProgram.objects.filter(accelerator=application).exists())

        application.status = "approved"
        application.save()

        self.assertTrue(AcceleratorProgram.objects.filter(accelerator=application).exists())
