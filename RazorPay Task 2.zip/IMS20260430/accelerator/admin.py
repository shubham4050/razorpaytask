from django.contrib import admin
from .models import (
    AcceleratorProgram,
    AcceleratorMilestone,
    AcceleratorDocument,
    AcceleratorNotice,
)

admin.site.register(AcceleratorProgram)
admin.site.register(AcceleratorMilestone)
admin.site.register(AcceleratorDocument)
admin.site.register(AcceleratorNotice)

