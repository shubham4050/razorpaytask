from django.urls import path
from . import views

app_name = "accelerator"

urlpatterns = [
    path("dashboard/", views.dashboard, name="dashboard"),
    path("profile/", views.profile, name="profile"),
    path("program/", views.program_details, name="program_details"),
    path("milestones/", views.milestones, name="milestones"),
    path("milestones/<int:pk>/submit/", views.milestone_submit, name="milestone_submit"),
    path("documents/", views.documents, name="documents"),
    path("notices/", views.notices, name="notices"),
]