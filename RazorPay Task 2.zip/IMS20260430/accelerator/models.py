from django.db import models
from applications.models import AcceleratorApplication


class AcceleratorProgram(models.Model):
    """Admin sets program details for each accelerator."""
    accelerator = models.OneToOneField(
        AcceleratorApplication,
        on_delete = models.CASCADE,
        related_name="program"
    )
    program_name = models.CharField(max_length=200, blank=True)
    batch_name = models.CharField(max_length=100, blank=True)
    start_date = models.DateField(null=True, blank=True)
    end_date = models.DateField(null=True, blank=True)
    current_stage = models.CharField(max_length=200, blank=True)
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.accelerator.startup_name} — {self.program_name}"


class AcceleratorMilestone(models.Model):
    """Milestones defined by admin, submitted by accelerator."""
    STATUS_CHOICES = (
        ("pending",   "Pending"),
        ("submitted", "Submitted"),
        ("approved",  "Approved"),
        ("rejected",  "Rejected"),
    )
    accelerator = models.ForeignKey(
        AcceleratorApplication,
        on_delete = models.CASCADE,
        related_name = "milestones"
    )
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    due_date = models.DateField(null=True, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="pending")
    submission_file = models.FileField(upload_to="accelerator_milestones/", blank=True)
    submission_note = models.TextField(blank=True)
    admin_feedback = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    submitted_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["due_date"]

    def __str__(self):
        return f"{self.accelerator.startup_name} — {self.title}"


class AcceleratorDocument(models.Model):
    """Documents uploaded by accelerator or shared by admin."""
    SOURCE_CHOICES = (
        ("accelerator", "Uploaded by Me"),
        ("admin", "Shared by Admin"),
    )
    accelerator = models.ForeignKey(
        AcceleratorApplication,
        on_delete=models.CASCADE,
        related_name="documents"
    )
    title = models.CharField(max_length=200)
    file = models.FileField(upload_to="accelerator_documents/")
    source = models.CharField(max_length=20, choices=SOURCE_CHOICES, default="accelerator")
    uploaded_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-uploaded_at"]

    def __str__(self):
        return f"{self.accelerator.startup_name} — {self.title}"


class AcceleratorNotice(models.Model):
    """Notices pushed by admin to accelerator."""
    accelerator = models.ForeignKey(
        AcceleratorApplication,
        on_delete=models.CASCADE,
        related_name="notices"
    )
    title = models.CharField(max_length=200)
    body = models.TextField()
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.accelerator.startup_name} — {self.title}"