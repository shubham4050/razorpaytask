from django.contrib.auth import update_session_auth_hash
from django.shortcuts import redirect, render, get_object_or_404
from django.contrib import messages
from django.utils import timezone
from accounts.portal_auth import portal_required
from .models import (
    AcceleratorProgram,
    AcceleratorMilestone,
    AcceleratorDocument,
    AcceleratorNotice,
)

# ── Auth decorator ────────────────────────────────────────────────────────────
accelerator_required = portal_required("accelerator")


# ── Dashboard ─────────────────────────────────────────────────────────────────
@accelerator_required
def dashboard(request):
    acc = request.accelerator
    program = AcceleratorProgram.objects.filter(accelerator=acc).first()
    milestones = acc.milestones.all()
    unread_notices = acc.notices.filter(is_read=False).count()

    total_milestones = milestones.count()
    approved_milestones = milestones.filter(status="approved").count()
    pending_milestones = milestones.filter(status="pending").count()

    context = {
        "accelerator": acc,
        "program": program,
        "total_milestones": total_milestones,
        "approved_milestones": approved_milestones,
        "pending_milestones": pending_milestones,
        "unread_notices": unread_notices,
        "recent_milestones": milestones[:3],
    }
    return render(request, "accelerator/dashboard.html", context)


# ── My Profile ────────────────────────────────────────────────────────────────
@accelerator_required
def profile(request):
    acc = request.accelerator
    profile_errors = {}
    password_errors = {}

    if request.method == "POST":
        action = request.POST.get("action")

        # ── Save editable profile fields ──────────────────────────────────────
        if action == "update_profile":
            contact_number      = request.POST.get("contact_number", "").strip()
            website             = request.POST.get("website", "").strip()
            facebook_link       = request.POST.get("facebook_link", "").strip()
            linked_link         = request.POST.get("linked_link", "").strip()
            one_line_description = request.POST.get("one_line_description", "").strip()
            startup_details     = request.POST.get("startup_details", "").strip()
            pitch_deck          = request.FILES.get("pitch_deck")

            if not contact_number:
                profile_errors["contact_number"] = "Contact number is required."
            if not one_line_description:
                profile_errors["one_line_description"] = "One line description is required."
            if not startup_details:
                profile_errors["startup_details"] = "Startup details are required."

            if not profile_errors:
                acc.contact_number       = contact_number
                acc.website              = website
                acc.facebook_link        = facebook_link
                acc.linked_link          = linked_link
                acc.one_line_description = one_line_description
                acc.startup_details      = startup_details
                if pitch_deck:
                    acc.pitch_deck = pitch_deck
                acc.save()
                messages.success(request, "Profile updated successfully.")
                return redirect("accelerator:profile")

        # ── Update password ───────────────────────────────────────────────────
        elif action == "update_password":
            current_password = request.POST.get("current_password", "").strip()
            new_password     = request.POST.get("new_password", "").strip()
            confirm_password = request.POST.get("confirm_password", "").strip()

            if not current_password:
                password_errors["current_password"] = "Current password is required."
            elif not request.user.check_password(current_password):
                password_errors["current_password"] = "Current password is incorrect."

            if not new_password:
                password_errors["new_password"] = "New password is required."
            elif len(new_password) < 5:
                password_errors["new_password"] = "Password must be at least 5 characters."

            if not confirm_password:
                password_errors["confirm_password"] = "Please confirm your new password."
            elif new_password and new_password != confirm_password:
                password_errors["confirm_password"] = "Passwords do not match."

            if not password_errors:
                request.user.set_password(new_password)
                request.user.save(update_fields=["password"])
                update_session_auth_hash(request, request.user)
                messages.success(request, "Password updated successfully.")
                return redirect("accelerator:profile")

    return render(request, "accelerator/profile.html", {
        "accelerator":     acc,
        "profile_errors":  profile_errors,
        "password_errors": password_errors,
    })

# ── Program Details ───────────────────────────────────────────────────────────
@accelerator_required
def program_details(request):
    acc = request.accelerator
    program = AcceleratorProgram.objects.filter(accelerator=acc).first()
    return render(request, "accelerator/program_details.html", {
        "accelerator": acc,
        "program": program,
    })


# ── Milestones ────────────────────────────────────────────────────────────────
@accelerator_required
def milestones(request):
    acc = request.accelerator
    milestones = acc.milestones.all()
    return render(request, "accelerator/milestones.html", {
        "accelerator": acc,
        "milestones": milestones,
    })


@accelerator_required
def milestone_submit(request, pk):
    acc = request.accelerator
    milestone = get_object_or_404(AcceleratorMilestone, pk=pk, accelerator=acc)

    if milestone.status not in ("pending", "rejected"):
        messages.error(request, "This milestone cannot be resubmitted.")
        return redirect("accelerator:milestones")

    if request.method == "POST":
        note = request.POST.get("submission_note", "").strip()
        file = request.FILES.get("submission_file")

        if not note and not file:
            messages.error(request, "Please provide a note or upload a file.")
        else:
            if file:
                milestone.submission_file = file
            milestone.submission_note = note
            milestone.status = "submitted"
            milestone.submitted_at = timezone.now()
            milestone.save()
            messages.success(request, f"Milestone '{milestone.title}' submitted successfully.")
            return redirect("accelerator:milestones")

    return render(request, "accelerator/milestone_submit.html", {
        "accelerator": acc,
        "milestone": milestone,
    })


# ── Documents ─────────────────────────────────────────────────────────────────
@accelerator_required
def documents(request):
    acc = request.accelerator
    docs = acc.documents.all()

    if request.method == "POST":
        title = request.POST.get("title", "").strip()
        file = request.FILES.get("file")
        if not title or not file:
            messages.error(request, "Title and file are required.")
        else:
            AcceleratorDocument.objects.create(
                accelerator=acc,
                title=title,
                file=file,
                source="accelerator",
            )
            messages.success(request, "Document uploaded successfully.")
            return redirect("accelerator:documents")

    return render(request, "accelerator/documents.html", {
        "accelerator": acc,
        "documents": docs,
    })


# ── Notices ───────────────────────────────────────────────────────────────────
@accelerator_required
def notices(request):
    acc = request.accelerator
    notices = acc.notices.all()
    # Mark all as read when page is opened
    notices.filter(is_read=False).update(is_read=True)
    return render(request, "accelerator/notices.html", {
        "accelerator": acc,
        "notices": notices,
    })
