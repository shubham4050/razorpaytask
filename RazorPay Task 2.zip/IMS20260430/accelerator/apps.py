from django.apps import AppConfig


class AcceleratorConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'accelerator'

    def ready(self):
        import accelerator.signals  # noqa: F401
