from django.shortcuts import render

from accounts.portal_auth import portal_required


startup_required = portal_required("startup")


@startup_required
def dashboard(request):
    return render(request, "startup/dashboard.html", {"startup": request.startup})
