from django.urls import path
from .views import dashboard

app_name = "startup"

urlpatterns = [
    path("dashboard/", dashboard, name="dashboard"),
    
]