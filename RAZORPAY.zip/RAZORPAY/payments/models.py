from decimal import Decimal

from django.core.exceptions import ValidationError
from django.db import models
from django.utils import timezone


class PromoCode(models.Model):
    DISCOUNT_PERCENT = "percent"
    DISCOUNT_FLAT = "flat"
    DISCOUNT_CHOICES = (
        (DISCOUNT_PERCENT, "Percentage"),
        (DISCOUNT_FLAT, "Flat amount"),
    )

    code = models.CharField(max_length=40, unique=True)
    description = models.CharField(max_length=200, blank=True)
    discount_type = models.CharField(max_length=20, choices=DISCOUNT_CHOICES)
    discount_value = models.DecimalField(max_digits=10, decimal_places=2)
    maximum_discount = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    minimum_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    razorpay_offer_id = models.CharField(
        max_length=80,
        help_text="Razorpay Dashboard Offer ID, for example offer_ANZoaxsOww2X53.",
    )
    is_active = models.BooleanField(default=True)
    valid_from = models.DateTimeField(null=True, blank=True)
    valid_until = models.DateTimeField(null=True, blank=True)
    max_redemptions = models.PositiveIntegerField(null=True, blank=True)
    times_redeemed = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["code"]

    def __str__(self):
        return self.code

    def clean(self):
        if self.discount_type == self.DISCOUNT_PERCENT and self.discount_value > 100:
            raise ValidationError({"discount_value": "Percentage discounts cannot be above 100."})
        if self.valid_from and self.valid_until and self.valid_from >= self.valid_until:
            raise ValidationError({"valid_until": "Valid until must be after valid from."})

    def is_available(self, amount):
        now = timezone.now()
        if not self.is_active:
            return False, "This promo code is inactive."
        if self.valid_from and now < self.valid_from:
            return False, "This promo code is not live yet."
        if self.valid_until and now > self.valid_until:
            return False, "This promo code has expired."
        if self.max_redemptions is not None and self.times_redeemed >= self.max_redemptions:
            return False, "This promo code has reached its usage limit."
        if Decimal(amount) < self.minimum_amount:
            return False, f"Minimum amount is INR {self.minimum_amount}."
        return True, ""

    def estimate_discount(self, amount):
        amount = Decimal(amount)
        if self.discount_type == self.DISCOUNT_PERCENT:
            discount = amount * self.discount_value / Decimal("100")
        else:
            discount = self.discount_value
        if self.maximum_discount is not None:
            discount = min(discount, self.maximum_discount)
        return min(discount.quantize(Decimal("0.01")), amount)


class PaymentOrder(models.Model):
    STATUS_CREATED = "created"
    STATUS_PAID = "paid"
    STATUS_FAILED = "failed"
    STATUS_CHOICES = (
        (STATUS_CREATED, "Created"),
        (STATUS_PAID, "Paid"),
        (STATUS_FAILED, "Failed"),
    )

    receipt = models.CharField(max_length=40, unique=True)
    customer_name = models.CharField(max_length=160)
    customer_email = models.EmailField()
    customer_phone = models.CharField(max_length=20)
    item_name = models.CharField(max_length=160)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    promo_code = models.ForeignKey(PromoCode, on_delete=models.SET_NULL, null=True, blank=True)
    estimated_discount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    estimated_payable = models.DecimalField(max_digits=10, decimal_places=2)
    razorpay_order_id = models.CharField(max_length=80, blank=True)
    razorpay_payment_id = models.CharField(max_length=80, blank=True)
    razorpay_signature = models.CharField(max_length=160, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=STATUS_CREATED)
    created_at = models.DateTimeField(auto_now_add=True)
    paid_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return self.receipt

