from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    initial = True

    dependencies = []

    operations = [
        migrations.CreateModel(
            name="PromoCode",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("code", models.CharField(max_length=40, unique=True)),
                ("description", models.CharField(blank=True, max_length=200)),
                ("discount_type", models.CharField(choices=[("percent", "Percentage"), ("flat", "Flat amount")], max_length=20)),
                ("discount_value", models.DecimalField(decimal_places=2, max_digits=10)),
                ("maximum_discount", models.DecimalField(blank=True, decimal_places=2, max_digits=10, null=True)),
                ("minimum_amount", models.DecimalField(decimal_places=2, default=0, max_digits=10)),
                ("razorpay_offer_id", models.CharField(help_text="Razorpay Dashboard Offer ID, for example offer_ANZoaxsOww2X53.", max_length=80)),
                ("is_active", models.BooleanField(default=True)),
                ("valid_from", models.DateTimeField(blank=True, null=True)),
                ("valid_until", models.DateTimeField(blank=True, null=True)),
                ("max_redemptions", models.PositiveIntegerField(blank=True, null=True)),
                ("times_redeemed", models.PositiveIntegerField(default=0)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
            ],
            options={"ordering": ["code"]},
        ),
        migrations.CreateModel(
            name="PaymentOrder",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("receipt", models.CharField(max_length=40, unique=True)),
                ("customer_name", models.CharField(max_length=160)),
                ("customer_email", models.EmailField(max_length=254)),
                ("customer_phone", models.CharField(max_length=20)),
                ("item_name", models.CharField(max_length=160)),
                ("amount", models.DecimalField(decimal_places=2, max_digits=10)),
                ("estimated_discount", models.DecimalField(decimal_places=2, default=0, max_digits=10)),
                ("estimated_payable", models.DecimalField(decimal_places=2, max_digits=10)),
                ("razorpay_order_id", models.CharField(blank=True, max_length=80)),
                ("razorpay_payment_id", models.CharField(blank=True, max_length=80)),
                ("razorpay_signature", models.CharField(blank=True, max_length=160)),
                ("status", models.CharField(choices=[("created", "Created"), ("paid", "Paid"), ("failed", "Failed")], default="created", max_length=20)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("paid_at", models.DateTimeField(blank=True, null=True)),
                ("promo_code", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, to="payments.promocode")),
            ],
            options={"ordering": ["-created_at"]},
        ),
    ]
