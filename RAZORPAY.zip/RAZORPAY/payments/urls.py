from django.urls import path

from . import views


app_name = "payments"

urlpatterns = [
    path("", views.checkout, name="checkout"),
    path("promo/validate/", views.validate_promo, name="validate_promo"),
    path("orders/create/", views.create_payment_order, name="create_order"),
    path("verify/", views.verify_payment, name="verify_payment"),
]

