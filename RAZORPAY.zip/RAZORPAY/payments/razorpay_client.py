import base64
import hashlib
import hmac
import json
import urllib.error
import urllib.request
from decimal import Decimal

from django.conf import settings


class RazorpayConfigurationError(Exception):
    pass


class RazorpayAPIError(Exception):
    pass


def amount_to_paise(amount):
    return int((Decimal(amount) * 100).quantize(Decimal("1")))


def create_order(*, amount, receipt, offer_id=None, notes=None):
    key_id = settings.RAZORPAY_KEY_ID
    key_secret = settings.RAZORPAY_KEY_SECRET
    if not key_id or not key_secret:
        raise RazorpayConfigurationError("Set RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET before creating orders.")

    payload = {
        "amount": amount_to_paise(amount),
        "currency": "INR",
        "receipt": receipt,
        "notes": notes or {},
    }
    if offer_id:
        payload["offers"] = [offer_id]
        payload["force_offer"] = True

    request = urllib.request.Request(
        "https://api.razorpay.com/v1/orders",
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Authorization": "Basic "
            + base64.b64encode(f"{key_id}:{key_secret}".encode("utf-8")).decode("ascii"),
            "Content-Type": "application/json",
        },
        method="POST",
    )

    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        raise RazorpayAPIError(exc.read().decode("utf-8", errors="replace")) from exc
    except urllib.error.URLError as exc:
        raise RazorpayAPIError(str(exc)) from exc


def verify_signature(*, order_id, payment_id, signature):
    payload = f"{order_id}|{payment_id}".encode("utf-8")
    expected = hmac.new(settings.RAZORPAY_KEY_SECRET.encode("utf-8"), payload, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, signature)

