from django.contrib import admin

from .models import PaymentOrder, PromoCode


@admin.register(PromoCode)
class PromoCodeAdmin(admin.ModelAdmin):
    list_display = ("code", "discount_type", "discount_value", "razorpay_offer_id", "is_active", "times_redeemed")
    list_filter = ("is_active", "discount_type")
    search_fields = ("code", "description", "razorpay_offer_id")
    readonly_fields = ("times_redeemed", "created_at")


@admin.register(PaymentOrder)
class PaymentOrderAdmin(admin.ModelAdmin):
    list_display = ("receipt", "item_name", "customer_email", "amount", "promo_code", "status", "created_at")
    list_filter = ("status", "promo_code")
    search_fields = ("receipt", "customer_email", "razorpay_order_id", "razorpay_payment_id")
    readonly_fields = ("created_at", "paid_at")

