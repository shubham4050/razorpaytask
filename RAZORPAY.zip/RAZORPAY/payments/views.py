import uuid
from decimal import Decimal

from django.conf import settings
from django.db import models, transaction
from django.http import JsonResponse
from django.shortcuts import render
from django.utils import timezone
from django.views.decorators.http import require_POST

from .models import PaymentOrder, PromoCode
from .razorpay_client import RazorpayAPIError, RazorpayConfigurationError, create_order, verify_signature


ITEM_NAME = "AI Builders Conference Pass"
ITEM_AMOUNT = Decimal("2999.00")


def checkout(request):
    return render(
        request,
        "payments/checkout.html",
        {
            "item_name": ITEM_NAME,
            "amount": ITEM_AMOUNT,
            "razorpay_key_id": settings.RAZORPAY_KEY_ID,
        },
    )


def promo_response(promo, amount):
    discount = promo.estimate_discount(amount)
    return {
        "code": promo.code,
        "description": promo.description,
        "discount_amount": str(discount),
        "estimated_payable": str(max(Decimal(amount) - discount, Decimal("0.00"))),
    }


@require_POST
def validate_promo(request):
    amount = Decimal(request.POST.get("amount", ITEM_AMOUNT))
    code = request.POST.get("promo_code", "").strip().upper()
    if not code:
        return JsonResponse({"valid": False, "message": "Enter a promo code."}, status=400)

    try:
        promo = PromoCode.objects.get(code__iexact=code)
    except PromoCode.DoesNotExist:
        return JsonResponse({"valid": False, "message": "Invalid promo code."}, status=404)

    is_available, message = promo.is_available(amount)
    if not is_available:
        return JsonResponse({"valid": False, "message": message}, status=400)

    return JsonResponse({"valid": True, "promo": promo_response(promo, amount)})


@require_POST
@transaction.atomic
def create_payment_order(request):
    amount = Decimal(request.POST.get("amount", ITEM_AMOUNT))
    promo = None
    estimated_discount = Decimal("0.00")
    code = request.POST.get("promo_code", "").strip().upper()

    if code:
        try:
            promo = PromoCode.objects.select_for_update().get(code__iexact=code)
        except PromoCode.DoesNotExist:
            return JsonResponse({"ok": False, "message": "Invalid promo code."}, status=404)

        is_available, message = promo.is_available(amount)
        if not is_available:
            return JsonResponse({"ok": False, "message": message}, status=400)
        estimated_discount = promo.estimate_discount(amount)

    receipt = f"promo-{uuid.uuid4().hex[:14]}"
    local_order = PaymentOrder.objects.create(
        receipt=receipt,
        customer_name=request.POST.get("name", "").strip(),
        customer_email=request.POST.get("email", "").strip(),
        customer_phone=request.POST.get("phone", "").strip(),
        item_name=ITEM_NAME,
        amount=amount,
        promo_code=promo,
        estimated_discount=estimated_discount,
        estimated_payable=max(amount - estimated_discount, Decimal("0.00")),
    )

    try:
        razorpay_order = create_order(
            amount=amount,
            receipt=receipt,
            offer_id=promo.razorpay_offer_id if promo else None,
            notes={"promo_code": promo.code if promo else "", "local_order_id": str(local_order.pk)},
        )
    except (RazorpayConfigurationError, RazorpayAPIError) as exc:
        local_order.status = PaymentOrder.STATUS_FAILED
        local_order.save(update_fields=["status"])
        return JsonResponse({"ok": False, "message": str(exc)}, status=502)

    local_order.razorpay_order_id = razorpay_order["id"]
    local_order.save(update_fields=["razorpay_order_id"])
    return JsonResponse(
        {
            "ok": True,
            "key": settings.RAZORPAY_KEY_ID,
            "order_id": razorpay_order["id"],
            "amount": razorpay_order["amount"],
            "currency": razorpay_order["currency"],
        }
    )


@require_POST
@transaction.atomic
def verify_payment(request):
    order = PaymentOrder.objects.select_for_update().get(
        razorpay_order_id=request.POST.get("razorpay_order_id", "")
    )
    payment_id = request.POST.get("razorpay_payment_id", "")
    signature = request.POST.get("razorpay_signature", "")

    if not verify_signature(order_id=order.razorpay_order_id, payment_id=payment_id, signature=signature):
        order.status = PaymentOrder.STATUS_FAILED
        order.save(update_fields=["status"])
        return JsonResponse({"ok": False, "message": "Signature verification failed."}, status=400)

    order.razorpay_payment_id = payment_id
    order.razorpay_signature = signature
    order.status = PaymentOrder.STATUS_PAID
    order.paid_at = timezone.now()
    order.save(update_fields=["razorpay_payment_id", "razorpay_signature", "status", "paid_at"])

    if order.promo_code_id:
        PromoCode.objects.filter(pk=order.promo_code_id).update(times_redeemed=models.F("times_redeemed") + 1)

    return JsonResponse({"ok": True, "message": "Payment verified."})

