const baseAmount = 2999;
const conferenceCode = "CONF100";
const discountPercent = 100;
const paymentLinkUrl = "https://rzp.io/l/REPLACE_WITH_YOUR_PAYMENT_LINK";

const couponInput = document.querySelector("#couponInput");
const applyCoupon = document.querySelector("#applyCoupon");
const discountText = document.querySelector("#discountText");
const totalPrice = document.querySelector("#totalPrice");
const demoMessage = document.querySelector("#demoMessage");
const paymentLink = document.querySelector("#paymentLink");
const copyChecklist = document.querySelector("#copyChecklist");

const formatINR = (amount) =>
  new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0
  }).format(amount);

function previewOffer() {
  const enteredCode = couponInput.value.trim().toUpperCase();

  if (enteredCode !== conferenceCode) {
    discountText.textContent = "Not applied";
    totalPrice.textContent = formatINR(baseAmount);
    demoMessage.textContent =
      "Code not matched. In production, Razorpay decides discount eligibility from the Dashboard Offer rules.";
    return;
  }

  const discount = Math.round((baseAmount * discountPercent) / 100);
  const payable = Math.max(baseAmount - discount, 0);

  discountText.textContent = `${discountPercent}% off preview`;
  totalPrice.textContent = formatINR(payable);
  demoMessage.textContent =
    "For live payment, replace the demo URL with your Razorpay Payment Link that has the Dashboard Offer enabled.";
}

function openPaymentLink(event) {
  if (paymentLinkUrl.includes("REPLACE_WITH_YOUR_PAYMENT_LINK")) {
    event.preventDefault();
    demoMessage.textContent =
      "Add your real Razorpay Payment Link in script.js before using this button.";
  }
}

async function copyDashboardChecklist() {
  const text = [
    "Razorpay conference discount checklist:",
    "1. Dashboard > Offers > Create New Offer.",
    "2. Offer name/display text: CONF100 or conference session name.",
    "3. Discount: Instant percentage/flat discount.",
    "4. Validity: start and end around the live conference session.",
    "5. Usage limit: near room capacity.",
    "6. Attach to Payment Link/Button/Page with Checkout Visibility enabled.",
    "7. Share QR/link only inside the room.",
    "8. Disable the Offer after the session."
  ].join("\n");

  try {
    await navigator.clipboard.writeText(text);
    copyChecklist.textContent = "Copied";
    setTimeout(() => {
      copyChecklist.textContent = "Copy checklist";
    }, 1800);
  } catch {
    copyChecklist.textContent = "Copy failed";
  }
}

applyCoupon.addEventListener("click", previewOffer);
paymentLink.addEventListener("click", openPaymentLink);
copyChecklist.addEventListener("click", copyDashboardChecklist);
previewOffer();
