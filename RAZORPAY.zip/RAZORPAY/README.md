# Razorpay Promo Code in Django

This folder contains two things:

- The original static explainer: `index.html`, `script.js`, `styles.css`
- A working Django demo that behaves like a Stripe-style promo code gate before Razorpay Checkout

## Why this is needed

Razorpay does not work exactly like Stripe promotion codes where the customer enters a code directly inside Stripe Checkout.

For Razorpay, create the discount as a **Razorpay Offer** in the Dashboard. Then in Django, create your own promo code such as `CONF100` and map it to that Razorpay `offer_id`.

Flow:

1. Customer enters `CONF100` on your Django checkout page.
2. Django validates status, expiry, usage limit, and minimum amount.
3. Django creates a Razorpay order with the matched `offer_id`.
4. Razorpay Checkout opens with only that offer available.
5. Django verifies the payment signature after payment.

## Setup

```powershell
cd C:\Users\RDRL\Desktop\V2\RAZORPAY
python -m pip install -r requirements.txt
python manage.py migrate
python manage.py createsuperuser
```

Razorpay test keys are already added in `razorpay_demo/settings.py`. You can still override them from PowerShell:

```powershell
$env:RAZORPAY_KEY_ID="rzp_test_xxxxx"
$env:RAZORPAY_KEY_SECRET="your_secret"
python manage.py runserver 127.0.0.1:8000
```

Open:

```text
http://127.0.0.1:8000/
```

Admin:

```text
http://127.0.0.1:8000/admin/
```

## Create a promo code

1. In Razorpay Dashboard, create an Offer.
2. Copy the Razorpay Offer ID, for example `offer_ANZoaxsOww2X53`.
3. In Django admin, open `Promo codes`.
4. Add:
   - Code: `CONF100`
   - Discount type: `Percentage` or `Flat amount`
   - Discount value: for display/estimate
   - Razorpay offer id: paste the real `offer_...` ID
   - Active, validity, and max redemptions as needed

## Important note

The Django page shows an estimated discount so users understand the offer. The Razorpay order is created for the original amount and the real discount is controlled by the Razorpay Offer. This avoids double-discounting.
